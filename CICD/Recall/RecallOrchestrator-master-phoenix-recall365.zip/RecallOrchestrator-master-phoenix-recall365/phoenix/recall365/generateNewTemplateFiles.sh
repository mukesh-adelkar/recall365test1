#!/usr/bin/env bash
#
# After replacing values, this script is called to generate new template yaml files for helm subcharts
# Arguments are: Cluster Name and Namespace
#
cd charts

for f in *; do
    if [ -d ${f} ]; then
        # Will not run if no directories are available
        echo "Generating template files for $f"
        cd ${f}
        rm templates/${f}.yaml
        cp ../../templates/* ./templates
        helm template --name ${f} --set global.cluster.hosts=$1.landmarksoftware.io --namespace $2 ./ --set global.env.production=false > ${f}.yaml
        rm -rf ./templates/*
        mv ${f}.yaml ./templates/${f}.yaml
        cd ..
    fi
done