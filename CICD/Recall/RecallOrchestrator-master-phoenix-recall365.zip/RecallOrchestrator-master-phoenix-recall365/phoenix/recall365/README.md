1. Remote into container:
docker run -it --rm -v C:\Users\h109057\.aws:/root/.aws  -v C:\Development\Recall\Git\RecallOrchestrator\phoenix:/root/app  -e http_proxy=http://hXXXXXX:<PASS>@calprxy801.corp.halliburton.com:80 distservices-docker.repo.openearth.io/distarch/dpcli-distplat3:1.0

2. Replace values in subchart values.yaml according to your deployment

3. Generate new yaml helm charts by running:
bash ./generateNewTemplateFiles.sh %cluster_name% %namespace%

4. Install Helm Charts:
helm install recall365 --name recall365 --set global.cluster.hosts=distplat3.landmarksoftware.io,global.env.production=false --tiller-namespace=recall-dev --namespace recall-dev

Delete Helm Charts:
helm delete --purge recall365 --tiller-namespace=recall-dev