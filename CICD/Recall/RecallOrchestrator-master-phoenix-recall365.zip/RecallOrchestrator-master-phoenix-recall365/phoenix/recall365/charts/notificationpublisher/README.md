Deploy yaml:
docker run --rm -v C:\Users\h109057\.aws:/root/.aws  -v C:\Development\Recall\Git\RecallOrchestrator\phoenix\notificationpublisher:/root/app  -e http_proxy=http://<HXXXXXXX>:<PASS>@<HALProxy>.corp.halliburton.com:80 distservices-docker.repo.openearth.io/distarch/dpcli-distplat2:1.0 kubectl apply -f /root/app/notificationpublisher.yaml -n recall-dev

Build Helm:
docker run --rm -v C:\Users\h109057\.aws:/root/.aws  -v C:\Development\Recall\Git\RecallOrchestrator\phoenix\notificationpublisher:/root/app  distservices-docker.repo.openearth.io/distarch/dpcli-distplat2:1.0 helm template --name notificationpublisher --set global.cluster.hosts=distplat2.landmarksoftware.io --namespace recall-dev --set global.env.production=false ./ > notificationpublisher.yaml

Azure:

Remote into container:
docker run -it --rm -v C:\Development\Recall\Git\RecallOrchestrator\phoenix:/root/app -e http_proxy=http://<USER>:<PASSWORD>@calprxy801.corp.halliburton.com:80 -e https_proxy=http://h109057:Witcher!9@calprxy801.corp.halliburton.com:80 distservices-docker.repo.openearth.io/distarch/dpcli-distdwp:1.0

Force Login:
kubectl get pods -n recall-dev

Build Helm:
helm template --name notificationpublisher --set global.custer.hosts=azure.distdwp.landmarksoftware.io --namespace recall-dev ./ --set global.env.production=false > notificationpublisher.yaml

Deploy yaml:
kubectl apply -f notificationpublisher.yaml -n recall-dev

NOTE
Kafka does not automatically create topics with this image. To create a topic, remote into the kafka container, and execute the following;
cd /opt/kafka_2.11-0.10.1.0/bin/
./kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic recallServer.<recall_proj_name>.process_event
