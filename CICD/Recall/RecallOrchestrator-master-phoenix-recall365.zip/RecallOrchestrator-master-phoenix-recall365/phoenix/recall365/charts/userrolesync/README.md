Deploy yaml:
docker run --rm -v C:\Users\h109057\.aws:/root/.aws  -v C:\Development\Recall\Git\RecallOrchestrator\phoenix\userrolesync:/root/app  -e http_proxy=http://<HXXXXXX>:<PASS>@<HALPROXY>.corp.halliburton.com:80 distservices-docker.repo.openearth.io/distarch/dpcli-distplat2:1.0 kubectl apply -f /root/app/userrolesync.yaml -n recall-dev

Build Helm:
docker run --rm -v C:\Users\h109057\.aws:/root/.aws  -v C:\Development\Recall\Git\RecallOrchestrator\phoenix\userrolesync:/root/app  distservices-docker.repo.openearth.io/distarch/dpcli-distplat2:1.0 helm template --name userrolesync --set global.cluster.hosts=distplat2.landmarksoftware.io --namespace recall-dev --set global.env.production=false ./ > userrolesync.yaml

Azure:

Remote into container:
docker run -it --rm -v C:\Development\Recall\Git\RecallOrchestrator\phoenix:/root/app -e http_proxy=http://<USER>:<PASSWORD>@calprxy801.corp.halliburton.com:80 -e https_proxy=http://h109057:Witcher!9@calprxy801.corp.halliburton.com:80 distservices-docker.repo.openearth.io/distarch/dpcli-distdwp:1.0

Force Login:
kubectl get pods -n recall-dev

Build Helm:
helm template --name userrolesync --set global.custer.hosts=azure.distdwp.landmarksoftware.io --namespace recall-dev ./ --set global.env.production=false > userrolesync.yaml

Deploy yaml:
kubectl apply -f userrolesync.yaml -n recall-dev