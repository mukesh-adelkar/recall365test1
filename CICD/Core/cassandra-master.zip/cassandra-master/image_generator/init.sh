#!/usr/bin/env bash

set -x -e

export DEPLOY_REGIONS="us-east-1"
export SOURCE_AMI="ami-07d0cf3af28718ef8"
export SOURCE_AMI_REGION="us-east-1"
export FACTORY="rd"
export PHASE="dev"
export ENGINEER="Jude Gonsalves"
export REQUESTOR="Jude Gonsalves"
export OWNER="Jude Gonsalves"
export AWS_ACCOUNTS="099253701690"

packer validate -var-file=${FACTORY}-${PHASE}.json packer.json
packer build -var-file=${FACTORY}-${PHASE}.json packer.json
