#!/usr/bin/env bash

set -x -e

sleep 60

sudo useradd ec2-user || :
sudo usermod -aG sudo,systemd-journal ec2-user
sudo cp -r /home/ubuntu/. /home/ec2-user
sudo chown -R ec2-user.ec2-user /home/ec2-user
sudo chsh -s /bin/bash ec2-user
echo 'ec2-user     ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers
#sudo sed -i.bak 's/# %wheel/%wheel/g' /etc/sudoers
#sudo sed -i 's/Defaults    requiretty/#Defaults    requiretty/g' /etc/sudoers

sudo apt-get update
sudo apt install openjdk-8-jre python dracut libjemalloc1 -y
echo "deb http://www.apache.org/dist/cassandra/debian 311x main" | sudo tee -a /etc/apt/sources.list.d/cassandra.sources.list
curl https://www.apache.org/dist/cassandra/KEYS | sudo apt-key add -
sudo apt-key adv --keyserver pool.sks-keyservers.net --recv-key A278B781FE4B2BDA
sudo apt-get update
sudo apt-get install cassandra -y
sudo apt  install -y docker.io

# This is to increase the "max locked memory", which can be displayed by running the command "ulimit -a"
tee -a /etc/security/limits.conf <<EOF 
* hard memlock unlimited
* soft memlock unlimited
EOF

sudo usermod -aG docker ec2-user
sudo usermod -aG docker ubuntu
