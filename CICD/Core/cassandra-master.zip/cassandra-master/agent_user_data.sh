#!/usr/bin/env bash
set -x
exec > >(tee /var/log/user-data.log|logger -t user-data ) 2>&1

mkdir -p /home/ec2-user/.ssh
sudo cp /home/ubuntu/.ssh/authorized_keys /home/ec2-user/.ssh/authorized_keys
sudo chown -R ec2-user.ec2-user /home/ec2-user/.ssh
ssh_key_path="/home/ec2-user/.ssh/id_rsa"
set +x
echo "${private_ssh_key}" > $${ssh_key_path}
set -x
chmod 600 $${ssh_key_path}

sleep 30
LOCAL_HOSTNAME=$(hostname -i)
touch $${LOCAL_HOSTNAME}
scp -o "StrictHostKeyChecking no" -i $${ssh_key_path} "$${LOCAL_HOSTNAME}" ec2-user@${bootstrap_ip_address}:/home/ec2-user/agents
shred /home/ec2-user/.ssh/id_rsa

cassandra_endpoint="${bootstrap_ip_address}:8080/cassandra.yaml"
cassandra_config="/home/ec2-user/cassandra.yaml"
while : ; do
    curl $${cassandra_endpoint} > $${cassandra_config}
    if [[ -f $${cassandra_config} && $(du -sb $${cassandra_config} | cut -f1) -gt 1000 ]] ; then
        echo "Successfully downloaded the file 'cassandra.yaml'"
        break
    else
        echo "Unable to download the file from $${cassandra_endpoint}..."
        sleep 10
    fi
done
jvm_endpoint="${bootstrap_ip_address}:8080/jvm.options"
jvm_config="/home/ec2-user/jvm.options"
while : ; do
    curl $${jvm_endpoint} > $${jvm_config}
    if [[ -f $${jvm_config} && $(du -sb $${jvm_config} | cut -f1) -gt 500 ]] ; then
        echo "Successfully downloaded the file 'cassandra.yaml'"
        break
    else
        echo "Unable to download the file from $${jvm_endpoint}..."
        sleep 10
    fi
done

sudo sed -i "s/{{LOCAL_HOSTNAME}}/'"$${LOCAL_HOSTNAME}"'/g" $${cassandra_config}

sudo service cassandra stop

sudo mdadm --create --verbose /dev/md0 --level=0 --name=oss --raid-devices=4 /dev/nvme0n1 /dev/nvme1n1 /dev/nvme2n1 /dev/nvme3n1
sudo mkfs.ext4 -L oss /dev/md0
sleep 10
sudo mdadm --detail --scan | sudo tee -a /etc/mdadm.conf
sudo dracut -H -f /boot/initramfs-$(uname -r).img $(uname -r)
sleep 10
sudo rm -rf /mnt/oss
sudo mkdir -p /mnt/oss
echo "LABEL=oss       /mnt/oss   ext4    defaults,nofail        0       2" | sudo tee -a /etc/fstab
sudo mount -a
sudo mkdir -p /mnt/oss/data
sudo chmod -R 777 /mnt/oss

sudo rm -rf /var/lib/cassandra/data/system/*
sudo cp $${cassandra_config} /etc/cassandra/cassandra.yaml
sudo cp $${jvm_config} /etc/cassandra/jvm.options
sudo service cassandra start
sleep 30
while ! nodetool status; do
    sudo service cassandra restart
    sleep 30
done
