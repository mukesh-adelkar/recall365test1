##Module for DocumentDB provisioning##

Run with the following variables:

    terraform apply -var master_username=<user> -var master_password=<pwd> \
                    -var eks_worker_nodes_sg_id=<foo> \
                    -var vpc_tfstate_bucket_name=<name> \
                    -var vpc_tfstate_bucket_key=<key> \
                    -var vpc_tfstate_bucket_region=<region> \
                    -var instance_count=3 \
                    [-var cluster_identifier=<identifier>] -auto-approve

Verify terraform plan:

    terraform plan -var master_username=user -var master_password=pwd \ 
                   -var eks_worker_nodes_sg_id=foo_sg -var cluster_identifier=test-db-cluster \
                   -var vpc_tfstate_bucket_name="halliburton-terraform-state" \
                   -var vpc_tfstate_bucket_key="jude/phoenix-distplat/vpc/terraform.tfstate" \
                   -var vpc_tfstate_bucket_region="us-east-1" \
                   -var instance_count=3


###Testing###

Tests may be run on the df14 Dev VM (or any other bootstraping node with aws credentials provided)

1. Go to the test folder
    `cd test`
2. Import dependencies (**NOTE:** you need to have go version >= 1.11.*)
    `go get -t ./...`
3. Run tests
    `go test docdb_infra_test.go -v --timeout 30m`


