package test

import (
	"context"
	"fmt"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/ec2"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"
	"math/rand"
	"os"
	"testing"
	"time"
)

var (
	backendFile   = "../backend.tf"
	backendBackup = backendFile + "backup"
	vpcID         = "vpc-0e5a58882974f1c64"
	awsRegion     = "us-east-1"
	svc           = createEC2ServiceClient(awsRegion)
)

//1. Create Security group
//2. Create Doc DB cluster using terraform module
//3. Validate terraform output
//4. Validate connection to DocDB (read/write to DB also) <= TODO
//5. Destroy DocDB cluster
//6. Destroy security group
func TestDocumentDBClusterCreation(t *testing.T) {
	rand.Seed(time.Now().UnixNano())

	expectedUser := "mongo"
	expectedPwd := "password"
	clusterIdentifier := fmt.Sprintf("phoenix-docdb-test-%d", rand.Int())
	tfstateBucketName := "halliburton-terraform-state"
	tfstateBucketKey := "jude/phoenix-distplat/vpc/terraform.tfstate"
	tfstateBucketRegion := awsRegion
	securityGroupID := createSecurityGroup()
	defer destroySecurityGroup(securityGroupID)

	fmt.Println("Hiding backend during test...")
	os.Rename(backendFile, backendBackup)
	defer os.Rename(backendBackup, backendFile)
	defer fmt.Println("Moving backend back...")

	terraformOptions := &terraform.Options{
		TerraformDir: "../",

		// Variables to pass to our Terraform code using -var options
		Vars: map[string]interface{}{
			"master_username":           expectedUser,
			"master_password":           expectedPwd,
			"eks_worker_nodes_sg_id":    securityGroupID,
			"vpc_tfstate_bucket_name":   tfstateBucketName,
			"vpc_tfstate_bucket_key":    tfstateBucketKey,
			"vpc_tfstate_bucket_region": tfstateBucketRegion,
			"instance_count":            1, //One instance will be enough for testing
			"cluster_identifier":        clusterIdentifier,
		},
	}
	fmt.Println(terraformOptions)

	// Destroy DocDB cluster
	defer terraform.Destroy(t, terraformOptions)

	terraform.InitAndApply(t, terraformOptions)

	docdbHost := terraform.Output(t, terraformOptions, "docdb_host")
	docdbUser := terraform.Output(t, terraformOptions, "docdb_master_username")
	docdbPwd := terraform.Output(t, terraformOptions, "docdb_master_password")

	// validate output
	assert.Equal(t, expectedUser, docdbUser, "User doesn't match expectation")
	assert.Equal(t, expectedPwd, docdbPwd, "Password doesn't match expectation")
	assert.NotNil(t, docdbHost, "DocumendDB host should not be nil!")

	// TODO: fix connection validation
	//	instanceID := createTestEC2Instance(t, securityGroupID, "subnet-07a1d1f7bfcc9f6ec")
	//	defer removeTestEC2Instance(instanceID)
	//	validateDBConnection(t, docdbHost, docdbUser, docdbPwd)
}

func validateDBConnection(t *testing.T, host string, user string, pwd string) {
	dns := fmt.Sprintf("mongodb://%s:%s@%s:27017", user, pwd, host)
	client, err := mongo.NewClient(options.Client().ApplyURI(dns))
	assert.Nil(t, err, "Could not create Mongo client")
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	err = client.Connect(ctx)
	defer client.Disconnect(ctx)
	assert.Nil(t, err, "Could not connect to DocumentDB instance")
	err = client.Ping(ctx, readpref.Primary())
	assert.Nil(t, err, "Cannot ping DB")

	fmt.Printf("Successfully connected to %s\n", dns)
}

func createEC2ServiceClient(region string) *ec2.EC2 {
	sess, err := session.NewSession(&aws.Config{
		Region: aws.String(region)},
	)
	if err != nil {
		panic(err)
	}
	return ec2.New(sess)
}

func createSecurityGroup() string {
	sgName := fmt.Sprintf("docdb-test-sg-%d", rand.Int())
	sgDesc := "docdb test sequrity group"

	createRes, err := svc.CreateSecurityGroup(&ec2.CreateSecurityGroupInput{
		GroupName:   aws.String(sgName),
		Description: aws.String(sgDesc),
		VpcId:       aws.String(vpcID),
	},
	)
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok {
			switch aerr.Code() {
			case "InvalidVpcID.NotFound":
				exitErrorf("Unable to find VPC with ID %q.", vpcID)
			case "InvalidGroup.Duplicate":
				exitErrorf("Security group %q already exists.", sgName)
			}
		}
		exitErrorf("Unable to create security group %q, %v", sgName, err)
	}
	sgID := aws.StringValue(createRes.GroupId)
	fmt.Printf("Created security group %s with VPC %s\n", sgID, vpcID)

	_, err = svc.AuthorizeSecurityGroupIngress(&ec2.AuthorizeSecurityGroupIngressInput{
		GroupId: aws.String(sgID),
		IpPermissions: []*ec2.IpPermission{
			(&ec2.IpPermission{}).
				SetIpProtocol("tcp").
				SetFromPort(22).
				SetToPort(22).
				SetIpRanges([]*ec2.IpRange{
					(&ec2.IpRange{}).
						SetCidrIp("10.134.192.0/21"),
				}),
			(&ec2.IpPermission{}).
				SetIpProtocol("tcp").
				SetFromPort(80).
				SetToPort(80).
				SetIpRanges([]*ec2.IpRange{
					{CidrIp: aws.String("0.0.0.0/0")},
				}),
		},
	})
	if err != nil {
		exitErrorf("Unable to set security group %q ingress, %v", sgName, err)
	}

	fmt.Println("Successfully set security group ingress")

	return sgID
}

func destroySecurityGroup(sgID string) {
	_, err := svc.DeleteSecurityGroup(&ec2.DeleteSecurityGroupInput{
		GroupId: aws.String(sgID)})
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok {
			switch aerr.Code() {
			case "InvalidGroupId.Malformed":
				fallthrough
			case "InvalidGroup.NotFound":
				exitErrorf("%s.", aerr.Message())
			}
		}
		exitErrorf("Unable to get descriptions for security groups, %v.", err)
	}
	fmt.Printf("Successfully delete security group %q.\n", sgID)
}

func exitErrorf(msg string, args ...interface{}) {
	fmt.Fprintf(os.Stderr, msg+"\n", args...)
	os.Exit(1)
}

func createTestEC2Instance(t *testing.T, sgID string, subnet string) string {
	keyName := getKeyPair("docdb-test")

	runResults, err := svc.RunInstances(&ec2.RunInstancesInput{
		SecurityGroupIds: []*string{aws.String(sgID)},
		ImageId:          aws.String("ami-6871a115"),
		InstanceType:     aws.String("t2.micro"),
		MinCount:         aws.Int64(1),
		MaxCount:         aws.Int64(1),
		SubnetId:         aws.String(subnet),
		KeyName:          aws.String(keyName),
	})
	if err != nil {
		assert.Nil(t, err, "Could not create EC2 instance")
		panic(err)
	}
	instanceID := *runResults.Instances[0].InstanceId
	fmt.Printf("EC2 instance %s has been created successfully\n", instanceID)
	return instanceID
}

func removeTestEC2Instance(instanceID string) {
	fmt.Printf("Removing %s instance...\n", instanceID)
	input := &ec2.TerminateInstancesInput{
		InstanceIds: []*string{
			aws.String(instanceID),
		},
	}

	result, err := svc.TerminateInstances(input)
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok {
			switch aerr.Code() {
			default:
				fmt.Println(aerr.Error())
			}
		} else {
			// Print the error, cast err to awserr.Error to get the Code and
			// Message from an error.
			fmt.Println(err.Error())
		}
		return
	}
	fmt.Println(result)

	fmt.Println("Waiting for instance termination...")
	for start := time.Now(); time.Since(start) < 60*time.Second; {
		time.Sleep(5 * time.Second)
		if getInstanceStatus(instanceID) == "terminated" {
			break
		}
	}
}

func getInstanceStatus(instanceID string) string {
	includeAll := true
	status, err := svc.DescribeInstanceStatus(&ec2.DescribeInstanceStatusInput{
		IncludeAllInstances: &includeAll,
		InstanceIds:         []*string{&instanceID},
	})

	if err != nil {
		panic(err)
	}
	foo := status.InstanceStatuses[0].InstanceState.Name
	fmt.Printf("%s instance status: %s\n", instanceID, *foo)
	return *foo
}

func getKeyPair(keyName string) string {
	if !isKeyPairPresent(keyName) {
		createKeyPair(keyName)
	} else {
		fmt.Printf("KeyPair %s already exists!\n", keyName)
	}
	return keyName
}

func createKeyPair(keyName string) string {
	result, err := svc.CreateKeyPair(&ec2.CreateKeyPairInput{
		KeyName: aws.String(keyName),
	})
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok && aerr.Code() == "InvalidKeyPair.Duplicate" {
			exitErrorf("Keypair %q already exists.", keyName)
		}
		exitErrorf("Unable to create key pair: %s, %v.", keyName, err)
	}

	fmt.Printf("Created key pair %q %s\n%s\n",
		*result.KeyName, *result.KeyFingerprint,
		*result.KeyMaterial)
	return *result.KeyName
}

func isKeyPairPresent(keyName string) (res bool) {
	res = false
	//  Returns a list of key pairs
	result, err := svc.DescribeKeyPairs(nil)
	if err != nil {
		exitErrorf("Unable to get key pairs, %v", err)
	}

	for _, pair := range result.KeyPairs {
		if *pair.KeyName == keyName {
			res = true
		}
	}
	return
}
