package test

import (
    "testing"
    "github.com/gruntwork-io/terratest/modules/terraform"
    "github.com/stretchr/testify/assert"
    "github.com/aws/aws-sdk-go/service/emr"
    "github.com/aws/aws-sdk-go/service/s3"
    "github.com/aws/aws-sdk-go/aws/session"
    "github.com/aws/aws-sdk-go/aws"
    "fmt"
    "os"
)

var (
    backendFile = "../backend.tf"
    backendBackup = backendFile + ".back"
    s3BucketName = "emr-phoenix-test"
    awsRegion = "us-east-1"
)


func TestEmrBuild(t * testing.T) {
    t.Parallel()

    clusterName: = "TestNewCluster"

    os.Rename(backendFile, backendBackup)

    terraformOptions: = & terraform.Options {
        TerraformDir: "../",

        Vars: map[string] interface {} {
            "cluster_name": clusterName,
            "engineer_name": "test",
            "core_instance_count": 3,
            "subnet": "subnet-0a493534b8db9b373",
            "region": awsRegion,
            "s3_bucket": s3BucketName,
            "project_name": clusterName,
            "environment": "development",
            "public_key_path": "~/.ssh/id_rsa.pub",
            "key_name": "emr-phoenix-cluster-key",
            "max_task_instances_count": 300,
            "ebs_volume_size": 1050,
            "emr_version": "emr-5.23.0",
            "private_ssh_key_ssm_path": "phoenix-dev-key",
            "master_instance_type": "c4.8xlarge",
            "core_instance_type": "c4.8xlarge",
            "task_instance_group1_type": "c4.8xlarge",
            "task_instance_group2_type": "c5.9xlarge",
            "vpc_tfstate_bucket_key": "phoenix/df14-test/.shared/components/vpc/terraform.tfstate",
            "vpc_tfstate_bucket_name": "halliburton-terraform-state",
            "vpc_tfstate_bucket_region": awsRegion,
        },
    }

    terraform.InitAndApply(t, terraformOptions)

    sess: = session.Must(session.NewSession())
    emrApi: = emr.New(sess, & aws.Config {
        Region: aws.String(awsRegion)
    })

    list, _: = emrApi.ListClusters( & emr.ListClustersInput {
        ClusterStates: aws.StringSlice([] string {
            "RUNNING"
        })
    })

    var clusterID = ""
    for _, cluster: = range list.Clusters {
        if (clusterName == * cluster.Name) {
            clusterID = * cluster.Id
            break
        }
    }

    clusterRequest, clusterResponse: = emrApi.DescribeClusterRequest( & emr.DescribeClusterInput {
        ClusterId: aws.String(clusterID)
    })
    errors: = clusterRequest.Send()
    fmt.Println(errors)
    assert.Nil(t, errors)
    fmt.Println(clusterResponse)
    assert.NotNil(t, clusterResponse)

    counterFilesInBucket: = s3Call(s3BucketName, clusterName)
    assert.NotEqual(t, 0, counterFilesInBucket)

    terraform.Destroy(t, terraformOptions)
    os.Rename(backendBackup, backendFile)

    counterFilesInBucketAfterClusterDestroy: = s3Call(s3BucketName, clusterName)

    assert.Equal(t, 0, counterFilesInBucketAfterClusterDestroy)
}

func s3Call(bucketName string, clusterName string) int {
    sess: = session.Must(session.NewSession())
    svc: = s3.New(sess, & aws.Config {
        Region: aws.String(awsRegion)
    })

        params: = & s3.ListObjectsInput {
        Bucket: aws.String(bucketName),
        Prefix: aws.String(clusterName),
    }

    resp, _: = svc.ListObjects(params)
    var counter = 0
    for _, key: = range resp.Contents {
        fmt.Println( * key.Key)
        counter = counter + 1
    }
    return counter
}