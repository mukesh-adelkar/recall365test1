package test

import (
        "testing"
        "flag"
        "github.com/stretchr/testify/assert"
        "github.com/aws/aws-sdk-go/service/emr"
        "github.com/aws/aws-sdk-go/aws/session"
        "github.com/aws/aws-sdk-go/service/s3"
        "github.com/aws/aws-sdk-go/aws"
        "fmt"
)

var clustername = flag.String("clustername", "", "")

var (
    s3BucketName = "emr-phoenix-test"
    awsRegion = "us-east-1"
)


func init() {
     flag.Parse()
}

func TestCreatedEmr(t *testing.T) {
    t.Parallel()

    initialEmrValidation(t, []string{"RUNNING", "WAITING"})

    counterFilesInBucket := s3Call(s3BucketName, *clustername)
    assert.NotEqual(t, 0, counterFilesInBucket)
}

func TestDeletedEmr(t *testing.T) {
    t.Parallel()

    initialEmrValidation(t, []string{"TERMINATED"})

    counterFilesInBucket := s3Call(s3BucketName, *clustername)
    assert.Equal(t, 0, counterFilesInBucket)
}

func initialEmrValidation(t *testing.T, clusterStates []string) {
    clusterResponse,errors := makeEmrRequest(*clustername, clusterStates)
    fmt.Println(errors)
    assert.Nil(t, errors)
    fmt.Println(clusterResponse)
    assert.NotNil(t, clusterResponse)
}

func makeEmrRequest(clusterName string, clusterStates []string) (*emr.DescribeClusterOutput, error) {
    sess := session.Must(session.NewSession())
    emrApi := emr.New(sess, &aws.Config{Region: aws.String("us-east-1")})

    list,_ := emrApi.ListClusters(&emr.ListClustersInput{ClusterStates: aws.StringSlice(clusterStates)})

    var clusterID = ""
    for _,cluster := range list.Clusters {
        if (*clustername == *cluster.Name) {
           clusterID = *cluster.Id
           break
        }
    }

    clusterRequest,clusterResponse := emrApi.DescribeClusterRequest(&emr.DescribeClusterInput{ClusterId: aws.String(clusterID)})
	errors := clusterRequest.Send()
	return clusterResponse,errors
}

func s3Call(bucketName string, clusterName string) int {
    sess := session.Must(session.NewSession())
    svc := s3.New(sess, & aws.Config {
        Region: aws.String(awsRegion),
    })

	params := & s3.ListObjectsInput {
        Bucket: aws.String(bucketName),
        Prefix: aws.String(clusterName),
    }

    resp,_ := svc.ListObjects(params)
    var counter = 0
    for _,key := range resp.Contents {
        fmt.Println( * key.Key)
        counter = counter + 1
    }
    return counter
}
