### How to use EMR validation test - validator for created or destroyed EMR:
 
 - install go with helps https://git.openearth.community/distplat/phoenix/blob/master/doc/developer-guide.md#how-to-install-go
 - `go get -t ./...`
 - `go test -v -run TestCreatedEmr -clustername <cluster_name>` for validation new cluster, which has been created
 - `go test -v -run TestDeletedEmr -clustername <cluster_name>` for validation new cluster, which has been deleted


 ### How to use EMR build test - build status validator:
- install go with helps first point of :
- execute `go test -v -run TestEmrBuild -timeout 40m`