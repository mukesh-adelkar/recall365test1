#!/bin/bash
job_id=$(cat /mnt/var/lib/info/job-flow.json | jq -r ".jobFlowId")
(crontab -l -u hadoop 2>/dev/null; echo "* * * * * /home/hadoop/setup_custommetrics.sh" $job_id) | crontab -
