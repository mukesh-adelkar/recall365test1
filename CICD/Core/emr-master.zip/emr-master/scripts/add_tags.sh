#!/bin/bash
set -x
job_id=$(sudo cat /mnt/var/lib/info/job-flow.json | jq -r ".jobFlowId")
CLUSTER_NAME=$(aws emr describe-cluster --cluster-id ${job_id} --query "Cluster.Name" --output text --region us-east-1)
for i in $(aws ec2 describe-instances --filters "Name=tag:aws:elasticmapreduce:instance-group-role,Values=TASK" "Name=tag:Name,Values=${CLUSTER_NAME}" --query "Reservations[*].Instances[*].InstanceId" --output text --region us-east-1); do aws ec2 create-tags --resources $i --tags Key=AgentExempt,Value=true --region us-east-1; done
