#!/bin/bash

if [ "$#" -ne 1 ]; then
  echo "Usage: ./provision_master.sh <S3_BUCKET_LOCATION>"
  exit 1
fi

echo 'start provisioning...' && \
aws s3 cp ${1}create_juputer_user.sh ~ && \
sudo docker stop jupyterhub && \
sudo sed -i '/c.JupyterHub.ssl_key/s/^/#/g' /etc/jupyter/conf/jupyterhub_config.py && \
sudo sed -i '/c.JupyterHub.ssl_cert/s/^/#/g' /etc/jupyter/conf/jupyterhub_config.py && \
hadoop fs -mkdir -p /user/jovyan && \
hadoop fs -chmod 777 /user/jovyan && \
sudo docker start jupyterhub && \
bash /home/hadoop/create_juputer_user.sh demo && \
echo 'end provisioning...'

aws s3 cp ${1}add_tags.sh ~
bash /home/hadoop/add_tags.sh

echo 'start setting compute node label'
yarn rmadmin -addToClusterNodeLabels "compute(exclusive=true)"
yarn rmadmin -addToClusterNodeLabels "default(exclusive=false)"
echo 'end compute node label setup'

INSTANCE_ROLE=$(jq .instanceRole /mnt/var/lib/info/extraInstanceData.json)

if [[ "$INSTANCE_ROLE" = '"MASTER"' ]];
then
  echo 'increase ganglia memory limit to 512M'
  sudo sed -i 's/memory_limit = 128M/memory_limit = 512M/g' /etc/alternatives/php.ini
  sudo service gmond stop
  sudo service gmetad stop
  sudo service gmond start
  sudo service gmetad start
  echo 'start setting custommetrics'
  sudo ls /home/hadoop
  bash /home/hadoop/setup_custommetrics_job.sh 
fi

#fix for exception seen in the log
sudo chmod 444 /var/aws/emr/userData.json

