### How to build spot-termination-exporter

1) `git clone --branch 0.0.1 https://github.com/banzaicloud/spot-termination-exporter.git && cd spot-termination-exporter`
2) `go build -a`
3) Test exporter with helps `./spot-termination-exporter`