#!/bin/bash
set -e
_starttime=`date +20\%y-\%m-\%dT\%H:\%M\:0000 --date '-300 seconds'`
_endtime=`date +20\%y-\%m-\%dT\%H:\%M\:0000`
_jobid=$1


function recordMetrics() {
        index=$1
        jobid=$2
        starttime=$3
        endtime=$4

        queuename=$(curl -s http://$HOSTNAME:8088/ws/v1/cluster/scheduler |  grep 'queueName' | python -c "import sys, json; print json.load(sys.stdin)['scheduler']['schedulerInfo']['queues']['queue'][$index]['queueName']")
        numApplications=$(curl -s http://$HOSTNAME:8088/ws/v1/cluster/scheduler |  grep 'queueName' | python -c "import sys, json; print json.load(sys.stdin)['scheduler']['schedulerInfo']['queues']['queue'][$index]['numApplications']")
        numActiveApplications=$(curl -s http://$HOSTNAME:8088/ws/v1/cluster/scheduler |  grep 'queueName' | python -c "import sys, json; print json.load(sys.stdin)['scheduler']['schedulerInfo']['queues']['queue'][$index]['numActiveApplications']")
        numPendingApplications=$(curl -s http://$HOSTNAME:8088/ws/v1/cluster/scheduler |  grep 'queueName' | python -c "import sys, json; print json.load(sys.stdin)['scheduler']['schedulerInfo']['queues']['queue'][$index]['numPendingApplications']")
        numContainers=$(curl -s http://$HOSTNAME:8088/ws/v1/cluster/scheduler |  grep 'queueName' | python -c "import sys, json; print json.load(sys.stdin)['scheduler']['schedulerInfo']['queues']['queue'][$index]['numContainers']")
        allocatedContainers=$(curl -s http://$HOSTNAME:8088/ws/v1/cluster/scheduler |  grep 'queueName' | python -c "import sys, json; print json.load(sys.stdin)['scheduler']['schedulerInfo']['queues']['queue'][$index]['allocatedContainers']")
        reservedContainers=$(curl -s http://$HOSTNAME:8088/ws/v1/cluster/scheduler |  grep 'queueName' | python -c "import sys, json; print json.load(sys.stdin)['scheduler']['schedulerInfo']['queues']['queue'][$index]['reservedContainers']")
        pendingContainers=$(curl -s http://$HOSTNAME:8088/ws/v1/cluster/scheduler |  grep 'queueName' | python -c "import sys, json; print json.load(sys.stdin)['scheduler']['schedulerInfo']['queues']['queue'][$index]['pendingContainers']")

        #echo $starttime $endtime $jobid
        IsIdle=$(aws cloudwatch get-metric-statistics --region us-east-1 --metric-name IsIdle --start-time $starttime --end-time $endtime --period 300 --namespace AWS/ElasticMapReduce --statistics Average  --dimensions Name=JobFlowId,Value=$jobid | python -c "import sys, json; print json.load(sys.stdin)['Datapoints'][0]['Average']")
        ContainerPending=$(aws cloudwatch get-metric-statistics --region us-east-1 --metric-name ContainerPending --start-time $starttime --end-time $endtime --period 300 --namespace AWS/ElasticMapReduce --statistics Average  --dimensions Name=JobFlowId,Value=$jobid | python -c "import sys, json; print json.load(sys.stdin)['Datapoints'][0]['Average']")
        ContainerAllocated=$(aws cloudwatch get-metric-statistics --region us-east-1 --metric-name ContainerAllocated --start-time $starttime --end-time $endtime --period 300 --namespace AWS/ElasticMapReduce --statistics Average  --dimensions Name=JobFlowId,Value=$jobid | python -c "import sys, json; print json.load(sys.stdin)['Datapoints'][0]['Average']")
        ContainerReserved=$(aws cloudwatch get-metric-statistics --region us-east-1 --metric-name ContainerReserved --start-time $starttime --end-time $endtime --period 300 --namespace AWS/ElasticMapReduce --statistics Average  --dimensions Name=JobFlowId,Value=$jobid | python -c "import sys, json; print json.load(sys.stdin)['Datapoints'][0]['Average']")
        ContainerPendingRatio=$(aws cloudwatch get-metric-statistics --region us-east-1 --metric-name ContainerPendingRatio --start-time $starttime --end-time $endtime --period 300 --namespace AWS/ElasticMapReduce --statistics Average  --dimensions Name=JobFlowId,Value=$jobid | python -c "import sys, json; print json.load(sys.stdin)['Datapoints'][0]['Average']")
        YARNMemoryAvailablePercentage=$(aws cloudwatch get-metric-statistics --region us-east-1 --metric-name YARNMemoryAvailablePercentage --start-time $starttime --end-time $endtime --period 300 --namespace AWS/ElasticMapReduce --statistics Average  --dimensions Name=JobFlowId,Value=$jobid | python -c "import sys, json; print json.load(sys.stdin)['Datapoints'][0]['Average']")

        echo $starttime $endtime ' queuename:'$queuename' numApplications:'$numApplications' numActiveApplications:'$numActiveApplications' numPendingApplications:'$numPendingApplications' numContainers:'$numContainers' allocatedContainers:'$allocatedContainers' reservedContainers:'$reservedContainers' pendingContainers:'$pendingContainers' IsIdle:'$IsIdle' ContainerPending:'$ContainerPending' ContainerPendingRatio:'$ContainerPendingRatio' YARNMemoryAvailablePercentage:'$YARNMemoryAvailablePercentage >> /var/log/queuemetrics.log

        if [[ $queuename == "compute" ]]
        then
                ComputeIsIdle=1.0
                ComputeContainerPendingReservedAllocated=0.0
                ComputeContainerPending=0.0
                ComputeContainerPendingRatio=0.0
                ComputeYARNMemoryAvailablePercentage=100.0
                if [[ numApplications -gt 0 ]]
                then
                        ComputeIsIdle=$IsIdle
                        ComputeContainerPendingReservedAllocated=$ContainerPending+$ContainerAllocated+$ContainerReserved
                        ComputeContainerPending=$ContainerPending
                        ComputeContainerPendingRatio=$ContainerPendingRatio
                        ComputeYARNMemoryAvailablePercentage=$YARNMemoryAvailablePercentage
                fi
#                echo $starttime $endtime ' queuename:'$queuename' numApplications:'$numApplications' ComputeIsIdle:'$ComputeIsIdle' ComputeContainerPending:'$ComputeContainerPending' ComputeContainerPendingRatio:'$ComputeContainerPendingRatio' ComputeYARNMemoryAvailablePercentage:'$ComputeYARNMemoryAvailablePercentage >> /var/log/custom.log
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "ComputeIsIdle" --value $ComputeIsIdle --unit "None" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "ComputeContainerPending" --value $ComputeContainerPending --unit "Count" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "ComputeContainerPendingRatio" --value $ComputeContainerPendingRatio --unit "Count" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "ComputeYARNMemoryAvailablePercentage" --value $ComputeYARNMemoryAvailablePercentage --unit "Percent" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "ComputeContainerPendingReservedAllocated" --value $ComputeContainerPendingReservedAllocated --unit "Count" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid
        fi


        if [[ $queuename == "default" ]]
        then
                DefaultIsIdle=1.0
                DefaultContainerPending=0.0
                DefaultContainerPendingRatio=0.0
                DefaultYARNMemoryAvailablePercentage=100.0
                DefaultContainerPendingReservedAllocated=0.0
                if [[ numApplications -gt 0 ]]
                then
                        DefaultIsIdle=$IsIdle
                        DefaultContainerPending=$ContainerPending
                        DefaultContainerPendingRatio=$ContainerPendingRatio
                        DefaultYARNMemoryAvailablePercentage=$YARNMemoryAvailablePercentage
                        DefaultContainerPendingReservedAllocated=$ContainerPending+$ContainerAllocated+$ContainerReserved
                fi
#                echo $starttime $endtime ' queuename:'$queuename' numApplications:'$numApplications' DefaultIsIdle:'$DefaultIsIdle' DefaultContainerPending:'$DefaultContainerPending' DefaultContainerPendingRatio:'$DefaultContainerPendingRatio' DefaultYARNMemoryAvailablePercentage:'$DefaultYARNMemoryAvailablePercentage >> /var/log/custom.log
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "DefaultIsIdle" --value $DefaultIsIdle --unit "None" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "DefaultContainerPending" --value $DefaultContainerPending --unit "Count" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "DefaultContainerPendingRatio" --value $DefaultContainerPendingRatio --unit "Count" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "DefaultYARNMemoryAvailablePercentage" --value $DefaultYARNMemoryAvailablePercentage --unit "Percent" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid
                aws cloudwatch put-metric-data --region us-east-1 --metric-name "DefaultContainerPendingReservedAllocated" --value $DefaultContainerPendingReservedAllocated --unit "Count" --namespace AWS/ElasticMapReduce --dimensions JobFlowId=$jobid

        fi

}

recordMetrics 0 $_jobid $_starttime $_endtime
recordMetrics 1 $_jobid $_starttime $_endtime
