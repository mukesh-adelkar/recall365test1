# Add users to container and JupyterHub with temp password of username
set -x
NEW_USER=${1}
TOKEN=$(sudo docker exec jupyterhub /opt/conda/bin/jupyterhub token jovyan | tail -1)
sudo docker exec jupyterhub useradd -m -s /bin/bash -N $NEW_USER
sudo docker exec jupyterhub bash -c "echo $NEW_USER:$NEW_USER | chpasswd"
curl -XPOST --silent -k https://$(hostname):9443/hub/api/users/$NEW_USER -H "Authorization: token $TOKEN" | jq
hadoop fs -mkdir /user/$NEW_USER && hadoop fs -chmod 777 /user/$NEW_USER
echo "user ${NEW_USER} has been created"
