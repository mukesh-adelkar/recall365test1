# Phoenix Platform (AWS) Release Notes #
----
## V3.6.0 ##

## V3.5.2 ##
1. Updated Filebeat helm chart to 0.1.4
2. Updated admin-app to version 1.0.2
3. Addition of "cluster.local" hosted-zone
4. Deployment of Rancher
5. Switch to the latest version of EKS module
6. Update of Istio version from 1.3.3 from 1.1.9
7. Namespace test update
8. DNS-switch script for blue-green deployment
9. Installation of DPBox, Plat Admin, Filebeat via Helm Charts
10. Add export from Prometheus to InfluxDB
11. Installation of SSM agent on VMs
12. Additional tests
13. Implement test harness for executing DSIS Postman tests

## V3.5.1 ##
1. Specified EKS worker AMIs
2. Added EMR job queue support 
3. Updated onboarding script to python
4. Upgraded to Terraform v0.12.7 and Terragrunt v0.19.21


## V3.5.0 ##
1. Added AWS MSK support
2. Set Prometheus retention time to 5 days to avoid storage overflow
3. Added Cassandra deployment
4. Migrate Go validation scripts to Python
5. Upgraded WebFramework and admin-app to version 1.0.2


## V3.4.1 ##
1. S3 bucket name changes: the Terraform variable `s3_bucket_name` => `eks_s3_bucket_name`. This is part of adding EMR bucket access policy to EKS policy. 
2. The EKS EC2 instances will now be given access to the EMR S3 bucket.
2. `PROTOCOL` environment variable for "platadmin" deployment.
3. Added helmcharts for "phoenixdemoapp" and "devportal"
4. Added script to list aws resources.
5. Run export DNS only after emr_setup.
6. Add "Cluster", "Workspace", "Owner", "Engineer" tags to bastion.
7. Add DSIS System Namespace `dsis-system` for DSIS components.
8. Fix the namespace cleanup in the helm namespace test.
9. Removal of the unused variable 's3_iam_policy'.
10. Parameterize installation of autoscaler.
11. Cluster autoscaler disabled by default and installed via helm chart.
12. Upgrated WebFramework to v1.0.1 and add webframework services "ODataService" and "DataQueryService".
13. Use SSM to manage aurora master password.
14. Install dedicated DocDB instance per cluster.
15. Enable merging cluster specific global config map. A new EKS module variable "plat_system_env" is added.
