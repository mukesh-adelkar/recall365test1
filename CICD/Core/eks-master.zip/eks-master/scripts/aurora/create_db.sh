#!/usr/bin/env bash

########################################################
### script for creating cluster database
######################################################## 

exec > >(tee /home/centos/phoenixdb.log|logger -t user-data ) 2>&1

set -x

OPERATION="CREATE"
while [ "$1" != "" ]; do
    case $1 in
        --destroy )    shift
                       OPERATION="DROP"
                       ;;
    esac
    shift
done
set -e

echo -e "${OPERATION} DATABASE ${PGDATABASE_NAME};" > phoenixdb.sql

if [[ ${OPERATION} == "CREATE" ]]; then
  USERNAMES=(postgres postgis)
  for username in ${USERNAMES[@]}; do
    echo -e "CREATE USER ${username} WITH PASSWORD '${username}';" >> phoenixdb.sql
    echo -e "ALTER USER ${username} WITH createdb;" >> phoenixdb.sql
    echo -e "ALTER USER ${username} WITH createrole;" >> phoenixdb.sql
    echo -e "GRANT rds_superuser to ${username};" >> phoenixdb.sql
    #echo -e "GRANT master to ${username};" >> phoenixdb.sql
  done
  echo -e "\l\n\du\n\n\n" >> phoenixdb.sql
  cat << EOF >> phoenixdb.sql
select current_user;
create extension postgis;
create extension fuzzystrmatch;
create extension postgis_tiger_geocoder;
create extension postgis_topology;
\dn
alter schema tiger owner to rds_superuser;
alter schema tiger_data owner to rds_superuser;
alter schema topology owner to rds_superuser;
\dn

CREATE FUNCTION exec(text) returns text language plpgsql volatile AS \$f\$ BEGIN EXECUTE \$1; RETURN \$1; END; \$f\$;

/* Call the above-defined function to transfer ownership of the PostGIS objects to the "rds_superuser" role */
SELECT exec('ALTER TABLE ' || quote_ident(s.nspname) || '.' || quote_ident(s.relname) || ' OWNER TO rds_superuser;')
  FROM (
    SELECT nspname, relname
    FROM pg_class c JOIN pg_namespace n ON (c.relnamespace = n.oid) 
    WHERE nspname in ('tiger','topology') AND
    relkind IN ('r','S','v') ORDER BY relkind = 'S')
s;  

/* Add "tiger" to your search path */
SET search_path=public,tiger;

/* Test "tiger" by using the following SELECT statement */
select na.address, na.streetname, na.streettypeabbrev, na.zip
from normalize_address('1 Devonshire Place, Boston, MA 02109') as na;

/* Test "topology" by using the following SELECT statement */
select topology.createtopology('my_new_topo',26986,0.5);
EOF
  echo -e "\nCreating database with name '${PGDATABASE_NAME}' and users for Postgres instance with hostname '${PGHOSTNAME}'..."
elif [[ ${OPERATION} == "DROP" ]]; then
  echo -e "\nDestroying database with name '${PGDATABASE_NAME}'..."
fi

export PGHOST="${PGHOSTNAME}"
export PGPORT="5432"
export PGUSER="${PGUSERNAME}"
export PGPASSWORD="${PGPASSWORD}"
export PGDATABASE="postgres"

psql -f phoenixdb.sql
