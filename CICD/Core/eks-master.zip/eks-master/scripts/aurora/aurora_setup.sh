#!/usr/bin/env bash

########################################################
### script for attaching aurora service to cluster
######################################################## 

set -x

# script for creating cluster database
bash ~/script/scripts/aurora/create_db.sh

# creating additional resources
OPERATION="create"
[[ $(kubectl describe secret aurora-postgres-master 2> /dev/null) ]] && OPERATION="replace"
kubectl create secret generic aurora-postgres-master --from-literal=username=${PGUSERNAME} --from-literal=password=${PGPASSWORD} -n plat-system -o yaml --dry-run | kubectl ${OPERATION} -f -
kubectl annotate secret aurora-postgres-master kubed.appscode.com/sync="" -n plat-system --overwrite
kubectl apply -f ~/script/manifest/system/postgres/postgres.yaml
