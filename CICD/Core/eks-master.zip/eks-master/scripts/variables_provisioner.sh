#!/bin/bash


########################################################
### script for creating environment variables which should be used during installation of cluster
######################################################## 

set -e

sleep 2

sudo find ~/script/manifest -type f | xargs sudo sed -i  "s/{{cluster}}/${CLUSTER_NAME}/g"
sudo find ~/script/manifest -type f | xargs sudo sed -i  "s/{{dns}}/${CLUSTER_DNS}/g"


export AWS_ACCESS_KEY_ID=$(aws configure get default.aws_access_key_id)
sleep 2
export AWS_SECRET_ACCESS_KEY=$(aws configure get default.aws_secret_access_key)
sleep 2

sudo sed -i "s#{{AWS_ACCESS_KEY_ID}}#${AWS_ACCESS_KEY_ID}#g" ~/script/manifest/system/monitoring/cloudwatch-datasource-configmap.yaml
sudo sed -i "s#{{AWS_SECRET_ACCESS_KEY}}#${AWS_SECRET_ACCESS_KEY}#g" ~/script/manifest/system/monitoring/cloudwatch-datasource-configmap.yaml

sudo sed -i "s#{{LOGSTASH}}#${LOGSTASH_URL}#g" ~/script/manifest/system/mml/filebeat.yaml
sudo sed -i "s#{{CLUSTER_NAME}}#${CLUSTER_NAME}#g" ~/script/manifest/system/mml/filebeat.yaml

sudo sed -i "s#{{EFS_FS}}#${EFS_FS}#g" ~/script/manifest/system/efs/efs.yaml
sudo sed -i "s#{{AWS_REGION}}#${AWS_REGION}#g" ~/script/manifest/system/efs/efs.yaml
sudo sed -i "s#{{EFS_SERVER}}#${EFS_SERVER}#g" ~/script/manifest/system/efs/efs.yaml

sudo sed -i "s#{{AWS_REGION}}#${AWS_REGION}#g" ~/script/manifest/system/autoscale/autoscaler.yaml
sudo sed -i "s#{{WORKERS_SECURITY_GROUP}}#${CLUSTER_ASG_ID}#g" ~/script/manifest/system/autoscale/autoscaler.yaml
sudo sed -i "s#{{AWS_REGION}}#${AWS_REGION}#g" ~/script/manifest/system/autoscale/cluster_autoscale_values.yaml

sudo sed -i "s#{{CLUSTER_NAME}}#${CLUSTER_NAME}#g" ~/script/manifest/system/kubed/plat-config.yaml
sudo sed -i "s#{{ENVIRONMENT}}#${ENVIRONMENT}#g" ~/script/manifest/system/kubed/plat-config.yaml
sudo sed -i "s#{{ENV_CRF_ID}}#${ENV_CRF_ID}#g" ~/script/manifest/system/kubed/plat-config.yaml
sudo sed -i "s#{{S3_BUCKET_NAME}}#${S3_BUCKET_NAME}#g" ~/script/manifest/system/kubed/plat-config.yaml
sudo sed -i "s#{{EMR_CLUSTER_NAME}}#${EMR_CLUSTER_NAME}#g" ~/script/manifest/system/kubed/plat-config.yaml
sudo sed -i "s#{{EMR_S3_BUCKET_NAME}}#${EMR_S3_BUCKET_NAME}#g" ~/script/manifest/system/kubed/plat-config.yaml
sudo sed -i "s#{{EMR_MASTER_DNS}}#${EMR_MASTER_DNS}#g" ~/script/manifest/system/kubed/plat-config.yaml
sudo sed -i "s#{{POSTGRES_NAME}}#${AURORA_CLUSTER_ID}#g" ~/script/manifest/system/kubed/plat-config.yaml
sudo sed -i "s#{{DISTPLAT_VERSION}}#${PLATFORM_VERSION}#g" ~/script/manifest/system/kubed/plat-config.yaml
sudo sed -i "s#{{AMAZON_DIGITAL_CERTIFICATE_URL}}#${AMAZON_DIGITAL_CERTIFICATE_URL}#g" ~/script/manifest/system/kubed/plat-config.yaml

sudo sed -i "s#{{AURORA_CLUSTER_ENDPOINT}}#${AURORA_CLUSTER_ENDPOINT}#g" ~/script/manifest/system/postgres/postgres.yaml

sudo sed -i "s#{{WORKERS_IAM_ARN}}#${IAM_ROLE_WORKERS_ARN}#g" ~/script/manifest/system/monitoring/customConfig.yaml
sudo sed -i "s#{{AWS_REGION}}#${AWS_REGION}#g" ~/script/manifest/system/monitoring/customConfig.yaml

sudo sed -i "s#{{DO_USE_HTTPS}}#${DO_USE_HTTPS}#g" ~/script/manifest/system/istio/svc-gateway.yaml
sudo sed -i "s#{{DO_USE_HTTPS}}#${DO_USE_HTTPS}#g" ~/script/manifest/system/istio/app-gateway.yaml

sudo sed -i "s#{{CLUSTER_NAME}}#${CLUSTER_NAME}#g" ~/script/manifest/system/azureidentitybinding/azureidentity.yaml
sudo sed -i "s#{{SUBSCRIPTION_ID}}#${SUBSCRIPTION_ID}#g" ~/script/manifest/system/azureidentitybinding/azureidentity.yaml
sudo sed -i "s#{{MANAGED_IDENTITY_CLIENT_ID}}#${MANAGED_IDENTITY_CLIENT_ID}#g" ~/script/manifest/system/azureidentitybinding/azureidentity.yaml
sudo sed -i "s#{{CLUSTER_NAME}}#${CLUSTER_NAME}#g" ~/script/manifest/system/azureidentitybinding/azureidentitybinding.yaml

sudo sed -i "s#{{INFLUXDB_NAME}}#${INFLUXDB_NAME}#g" ~/script/manifest/system/monitoring/customConfig.yaml
sudo sed -i "s#{{INFLUXDB_DB}}#${INFLUXDB_DB}#g" ~/script/manifest/system/monitoring/customConfig.yaml
sudo sed -i "s#{{INFLUXDB_USER}}#${INFLUXDB_USER}#g" ~/script/manifest/system/monitoring/customConfig.yaml

sudo sed -i -e "s#{{CLUSTER_NAME}}#${CLUSTER_NAME}#g" -e "s#{{CLOUD_VENDOR}}#${CLOUD_VENDOR}#g" -e "s#{{REGION}}#${REGION}#g" -e "s#{{ENVIRONMENT}}#${ENVIRONMENT}#g" ~/script/manifest/system/monitoring/newrelic-infrastructure-k8s-latest.yaml

sudo sed -i "s#{{DOCUMENTDB-HOST}}#${MONGO_HOST}#g" ~/script/manifest/system/docdb/mongodb.yaml

sudo sed -i "s#{{NEWRELIC_LICENSE_KEY}}#${NEWRELIC_LICENSE_KEY}#g" ~/script/manifest/system/monitoring/newrelic-infrastructure-k8s-latest.yaml
sudo sed -i "s#{{CLUSTER_NAME}}#${CLUSTER_NAME}#g" ~/script/manifest/system/monitoring/newrelic-infrastructure-k8s-events-latest.yaml
sudo sed -i "s#{{NEWRELIC_LICENSE_KEY}}#${NEWRELIC_LICENSE_KEY}#g" ~/script/manifest/system/monitoring/newrelic-infrastructure-k8s-events-latest.yaml

# Hard coding of even the parameter store should be avoided, should get rid of them in V2
# TODO
#export KEYCLOAK_LOGIN=$(aws ssm get-parameter --with-decryption --name "/rd/dev/phoenix/support/keycloak_username" --output text --query Parameter.Value)
#export KEYCLOAK_PWD=$(aws ssm get-parameter --with-decryption --name "/rd/dev/phoenix/support/keycloak_password" --output text --query Parameter.Value)

#sudo sed -i "s#{{KEYCLOAK_USERNAME}}#\"${KEYCLOAK_LOGIN}\"#g" ~/script/manifest/system/auth/dssecurity.yaml
#sudo sed -i "s#{{KEYCLOAK_PASSWORD}}#\"${KEYCLOAK_PWD}\"#g" ~/script/manifest/system/auth/dssecurity.yaml
