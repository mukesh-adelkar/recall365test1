#!/bin/bash
#HELM INSTALLATION
#set -e
set -x
#exec > >(sudo tee /var/log/platform.log|logger -t user-data ) 2>&1
sleep 2

########################################################
### Setup the cluster requirements
########################################################

#exec > >(sudo tee /var/log/platform.log|logger -t user-data ) 2>&1

# provision cluster name and format of history command during cluster installation
echo "export PS1=\"[\u@\h (${CLUSTER_NAME}) \W]\$ \"" >> /home/centos/.bashrc
echo 'export HISTTIMEFORMAT="%y/%m/%d %T "' >> /home/centos/.bashrc

# Set time zone
sudo rm -f /etc/localtime
sudo ln -sf /usr/share/zoneinfo/America/Chicago /etc/localtime

# Install Helm
mkdir helm
wget -O helm/helm.tar.gz https://get.helm.sh/helm-v3.0.3-linux-amd64.tar.gz
tar -zxvf helm/helm.tar.gz -C helm --strip-components=1
sudo cp helm/helm /usr/local/bin/
sudo chmod a+x /usr/local/bin/helm
rm -rf helm

sleep 20
# Do it again as it doesn't harm in case bootstrap node doesn't have kubectl installed
kubectl apply -f ~/script/aws_auth_configmap.yaml

cd ~/
kubectl apply -f ~/script/manifest/system/helm/helm-rbac-config.yaml
sleep 10
kubectl create namespace istio-system

#output=$(kubectl get pods --namespace kube-system | grep tiller)

# Install helmfile
mkdir helmfile
wget -O helmfile/helmfile https://github.com/roboll/helmfile/releases/download/v0.98.2/helmfile_linux_amd64 
sudo cp helmfile/helmfile /usr/local/bin/
sudo chmod a+x /usr/local/bin/helmfile
helm plugin install https://github.com/databus23/helm-diff --version=v3.0.0-rc.7
helm plugin install https://github.com/futuresimple/helm-secrets --version=v2.0.2
helm plugin install https://github.com/hypnoglow/helm-s3.git --version=v0.9.0
helm plugin install https://github.com/aslafy-z/helm-git.git --version=v0.5.0
rm -rf helmfile

#echo $output
#helm version

# Stable repo for Helm3
helm repo add stable https://kubernetes-charts.storage.googleapis.com/ && helm repo update

##### Istio
ISTIO_VERSION=1.4.5
helm repo add istio.io https://storage.googleapis.com/istio-release/releases/${ISTIO_VERSION}/charts/

helm install istio-init istio.io/istio-init --version ${ISTIO_VERSION} --namespace istio-system

kubectl -n istio-system wait --for=condition=complete job/istio-init-crd-10-${ISTIO_VERSION}
kubectl -n istio-system wait --for=condition=complete job/istio-init-crd-11-${ISTIO_VERSION}
kubectl -n istio-system wait --for=condition=complete job/istio-init-crd-14-${ISTIO_VERSION}

#set +x

if [[ ${DO_USE_HTTPS} == "true" ]]; then
  echo "Configuring Istio for use with HTTPS..."
  helm install istio istio.io/istio --version ${ISTIO_VERSION} \
  --namespace istio-system \
  --set global.proxy.includeIPRanges="0.0.0.0" \
  --set global.proxy.readinessInitialDelaySeconds=10 \
  --set tracing.enabled=true \
  --set mixer.policy.enabled=false \
  --set mixer.telemetry.enabled=true \
  --set sidecarInjectorWebhook.rewriteAppHTTPProbe=true \
  --set gateways.istio-ingressgateway.serviceAnnotations.'service\.beta\.kubernetes\.io/aws-load-balancer-ssl-cert'="${CERT_ARN}" \
  --set gateways.istio-ingressgateway.serviceAnnotations.'service\.beta\.kubernetes\.io/aws-load-balancer-ssl-ports'="https" \
  --set gateways.istio-ingressgateway.serviceAnnotations.'service\.beta\.kubernetes\.io/aws-load-balancer-connection-idle-timeout'="60" \
  --set gateways.istio-ingressgateway.serviceAnnotations.'service\.beta\.kubernetes\.io/aws-load-balancer-additional-resource-tags'="Environment=${ENVIRONMENT}\,BusinessOwner=${BUSINESSOWNER}\,Project=${PROJECT}\,Version=${VERSION}" \
  --set galley.replicaCount=2 \
  --set gateways.istio-ingressgateway.autoscaleMin=2 \
  --set pilot.autoscaleMin=2 \
  --set mixer.telemetry.replicaCount=2 \
  --set mixer.telemetry.autoscaleMin=2 \
  --set pilot.podAntiAffinityLabelSelector[0].key=app --set pilot.podAntiAffinityLabelSelector[0].operator=In \
  --set pilot.podAntiAffinityLabelSelector[0].value=pilot --set pilot.podAntiAffinityLabelSelector[0].values=pilot \
  --set pilot.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set mixer.podAntiAffinityLabelSelector[0].key=app --set mixer.podAntiAffinityLabelSelector[0].operator=In  \
  --set mixer.podAntiAffinityLabelSelector[0].value=telemetry --set mixer.podAntiAffinityLabelSelector[0].values=telemetry \
  --set mixer.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set galley.podAntiAffinityLabelSelector[0].key=app --set galley.podAntiAffinityLabelSelector[0].operator=In \
  --set galley.podAntiAffinityLabelSelector[0].value=galley --set galley.podAntiAffinityLabelSelector[0].values=galley \
  --set galley.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set gateways.istio-ingressgateway.ports[0].port=80 \
  --set gateways.istio-ingressgateway.ports[0].name=http2 \
  --set gateways.istio-ingressgateway.ports[0].targetPort=80 \
  --set gateways.istio-ingressgateway.ports[1].port=443 \
  --set gateways.istio-ingressgateway.ports[1].name=https \
  --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].key=app --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].operator=In \
  --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].value=istio-ingressgateway \
  --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].values=istio-ingressgateway \
  --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set sidecarInjectorWebhook.replicaCount=2 \
  --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].key=app --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].operator=In \
  --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].value=sidecarInjectorWebhook --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].values=sidecarInjectorWebhook \
  --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set gateways.istio-ingressgateway.loadBalancerSourceRanges="{${VPC_CIDR},${NAT_PUBLIC_IP_ADDRESS}/32,${BASTION_PUBLIC_IP_ADDRESS}/32}" \
  --set gateways.istio-ingressgateway.serviceAnnotations.service.beta.kubernetes.io/aws-load-balancer-extra-security-groups={${LB_INGRESS_SG}} \
  --wait
#  --debug
else
  echo "Configuring Istio without HTTPS..."
  helm install istio istio.io/istio --version ${ISTIO_VERSION} \
  --namespace istio-system \
  --set global.proxy.includeIPRanges="0.0.0.0" \
  --set global.proxy.readinessInitialDelaySeconds=10 \
  --set tracing.enabled=true \
  --set mixer.policy.enabled=false \
  --set mixer.telemetry.enabled=true \
  --set sidecarInjectorWebhook.rewriteAppHTTPProbe=true \
  --set gateways.istio-ingressgateway.serviceAnnotations.'service\.beta\.kubernetes\.io/aws-load-balancer-additional-resource-tags'="Environment=${ENVIRONMENT}\,BusinessOwner=${BUSINESSOWNER}\,Project=${PROJECT}\,Version=${VERSION}" \
  --set galley.replicaCount=2 \
  --set gateways.istio-ingressgateway.autoscaleMin=2 \
  --set pilot.autoscaleMin=2 \
  --set mixer.telemetry.replicaCount=2 \
  --set mixer.telemetry.autoscaleMin=2 \
  --set pilot.podAntiAffinityLabelSelector[0].key=app --set pilot.podAntiAffinityLabelSelector[0].operator=In \
  --set pilot.podAntiAffinityLabelSelector[0].value=pilot --set pilot.podAntiAffinityLabelSelector[0].values=pilot \
  --set pilot.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set mixer.podAntiAffinityLabelSelector[0].key=app --set mixer.podAntiAffinityLabelSelector[0].operator=In  \
  --set mixer.podAntiAffinityLabelSelector[0].value=telemetry --set mixer.podAntiAffinityLabelSelector[0].values=telemetry \
  --set mixer.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set galley.podAntiAffinityLabelSelector[0].key=app --set galley.podAntiAffinityLabelSelector[0].operator=In \
  --set galley.podAntiAffinityLabelSelector[0].value=galley --set galley.podAntiAffinityLabelSelector[0].values=galley \
  --set galley.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set gateways.istio-ingressgateway.ports[0].port=80 \
  --set gateways.istio-ingressgateway.ports[0].name=http2 \
  --set gateways.istio-ingressgateway.ports[0].targetPort=80 \
  --set gateways.istio-ingressgateway.ports[1].port=443 \
  --set gateways.istio-ingressgateway.ports[1].name=https \
  --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].key=app --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].operator=In \
  --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].value=istio-ingressgateway \
  --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].values=istio-ingressgateway \
  --set gateways.istio-ingressgateway.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set sidecarInjectorWebhook.replicaCount=2 \
  --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].key=app --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].operator=In \
  --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].value=sidecarInjectorWebhook --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].values=sidecarInjectorWebhook \
  --set sidecarInjectorWebhook.podAntiAffinityLabelSelector[0].topologyKey="kubernetes.io/hostname" \
  --set gateways.istio-ingressgateway.loadBalancerSourceRanges="{${VPC_CIDR},${NAT_PUBLIC_IP_ADDRESS}/32,${BASTION_PUBLIC_IP_ADDRESS}/32}" \
  --set gateways.istio-ingressgateway.serviceAnnotations.service.beta.kubernetes.io/aws-load-balancer-extra-security-groups={${LB_INGRESS_SG}} \
  --wait
#  --debug
fi

#set -x


# enable istio auto injection
sleep 20
kubectl label namespace default istio-injection=enabled --overwrite

##### Platform System
export SYSTEM_NAMESPACE="plat-system"
kubectl create namespace ${SYSTEM_NAMESPACE} || true
kubectl label namespace ${SYSTEM_NAMESPACE} istio-injection=enabled || true

sleep 10
kubectl apply -f ~/script/manifest/system/auth/service-account.yaml

##### Kubed - spread annotated config maps and secrets among all namespaces
helm repo add appscode https://charts.appscode.com/stable/ && helm repo update && helm search repo appscode/kubed
helm install kubed appscode/kubed --version 0.9.0 \
  --namespace ${SYSTEM_NAMESPACE} \
  --set apiserver.ca="$(onessl get kube-ca --analytics=false)" \
  --set config.clusterName=${CLUSTER_NAME} \
  --set resources.requests.cpu="50m",resources.requests.memory="256Mi",resources.limits.cpu="100m",resources.limits.memory="1024Mi"

# global config map
[ -f /home/centos/script/manifest/system/kubed/plat-spec-config.yaml ] && docker run --rm -v /home/centos/script/manifest/system/kubed:/workdir mikefarah/yq:2.4.0 yq m -ix plat-config.yaml plat-spec-config.yaml
kubectl apply -f ~/script/manifest/system/kubed/plat-config.yaml

# Simple tcp-echo service for further testing purpose
kubectl apply -n ${SYSTEM_NAMESPACE} -f ~/script/manifest/system/istio/tcp-echo.yaml

# private ingress
sleep 10

HELM_NGINX_ARGS=\
"--namespace ${SYSTEM_NAMESPACE} --version 1.6.7 --wait \
--set tcp.9000=\"plat-system/tcp-echo:9000\" \
--set controller.service.targetPorts.http=\"http\" \
--set controller.service.targetPorts.https=\"http\" \
--set controller.service.annotations.\"service\.beta\.kubernetes\.io/aws-load-balancer-backend-protocol\"=\"tcp\" \
--set controller.service.annotations.\"service\.beta\.kubernetes\.io/aws-load-balancer-connection-idle-timeout\"=\"3600\" \
--set controller.service.annotations.\"service\.beta\.kubernetes\.io/aws-load-balancer-additional-resource-tags\"=\"Environment=${ENVIRONMENT}\,BusinessOwner=${BUSINESSOWNER}\,Project=${PROJECT}\,Version=${VERSION}\""

[[ "${DO_USE_HTTPS}" == "true" ]] && HELM_NGINX_ARGS=\
"${HELM_NGINX_ARGS} \
--set controller.service.annotations.\"service\.beta\.kubernetes\.io/aws-load-balancer-ssl-cert\"=\"${CERT_ARN}\" \
--set controller.service.annotations.\"service\.beta\.kubernetes\.io/aws-load-balancer-ssl-ports\"=\"https\""

[[ "${DO_CREATE_INTERNAL_ADMIN_LB}" == "true" ]] && HELM_NGINX_ARGS=\
"${HELM_NGINX_ARGS} \
--set controller.service.annotations.\"service\.beta\.kubernetes\.io/aws-load-balancer-internal\"=\"0.0.0.0/0\""

eval "helm install nginx-ingress stable/nginx-ingress ${HELM_NGINX_ARGS}"

sleep 30
kubectl patch services nginx-ingress-controller --namespace ${SYSTEM_NAMESPACE} --patch "$(cat ~/script/manifest/system/ingress/patch-svc-nginx-ingress-controller.yaml)"
kubectl patch configmaps nginx-ingress-tcp --namespace ${SYSTEM_NAMESPACE} --patch "$(cat ~/script/manifest/system/ingress/patch-configmap-nginx-ingress-tcp.yaml)"
kubectl apply -f ~/script/manifest/system/ingress/ingress.yaml
#kubectl apply -f ~/script/manifest/system/ingress/nginx-tcp-configmap.yaml

# install plat admin ingress
kubectl apply -f ~/script/manifest/system/ingress/plat-admin-ingress.yaml

# Aurora setup
bash ~/script/scripts/aurora/aurora_setup.sh

#################################################################
############### Secrets Management for application onboarding
#################################################################

# should not be exported, nodes will have permissions
# AWS_ACCESS_KEY_ID=$(aws configure get default.aws_access_key_id)
# AWS_SECRET_ACCESS_KEY=$(aws configure get default.aws_secret_access_key)
# ASSUME_ROLE_ARN=$(aws configure get ${AWS_PROFILE}.role_arn)
# sleep 10
# kubectl create secret generic aws-secret --from-literal=username="${AWS_ACCESS_KEY_ID}" --from-literal=password="${AWS_SECRET_ACCESS_KEY}" -n ${SYSTEM_NAMESPACE} || true
# sleep 10

## Setup secrets

sleep 10
kubectl create secret docker-registry ienergyreg --docker-server=distplat-docker-milestone.hub.ienergycloud.io --docker-username=${IENERGY_LOGIN} --docker-password=${IENERGY_PWD} -n ${SYSTEM_NAMESPACE} || true
kubectl annotate secret ienergyreg kubed.appscode.com/sync="" -n ${SYSTEM_NAMESPACE}

kubectl create secret generic owdb-secret --from-literal=db_user="centos" --from-literal=db_user_pwd="centos" -n ${SYSTEM_NAMESPACE}

kubectl create secret generic wfadminapp-secret --from-literal=wfusername=${KEYCLOAK_LOGIN} --from-literal=wfpassword=${KEYCLOAK_PWD} -n ${SYSTEM_NAMESPACE}
kubectl annotate secret wfadminapp-secret kubed.appscode.com/sync="" -n ${SYSTEM_NAMESPACE}

kubectl create secret generic wf-key --from-literal=crypto_key=${CRYPTO_KEY} -n ${SYSTEM_NAMESPACE}
kubectl annotate secret wf-key kubed.appscode.com/sync="" -n ${SYSTEM_NAMESPACE}

# DSSecurity Secret
# TODO: remove username/password pair after February 28, 2020
kubectl create secret generic dssecurity-secret --from-literal=KC_ADMIN_USER=${KEYCLOAK_LOGIN} \
    --from-literal=KC_ADMIN_PASS=${KEYCLOAK_PWD} \
    --from-literal=username=${KEYCLOAK_LOGIN} \
    --from-literal=password=${KEYCLOAK_PWD} \
    -n ${SYSTEM_NAMESPACE}
kubectl annotate secret dssecurity-secret kubed.appscode.com/sync="" -n ${SYSTEM_NAMESPACE}

kubectl create secret generic mongo-secret --from-literal=db_user=${MONGO_LOGIN} --from-literal=db_pwd=${MONGO_PWD} -n ${SYSTEM_NAMESPACE}
kubectl annotate secret mongo-secret kubed.appscode.com/sync="" -n ${SYSTEM_NAMESPACE}

kubectl create secret generic grafana-secret --from-literal=username=${GRAFANA_USERNAME} \
  --from-literal=password=${GRAFANA_PASSWORD} -n ${SYSTEM_NAMESPACE}

kubectl create secret generic newrelic-account-details  --from-literal=accountid=${NEWRELIC_ACCOUNTID} \
  --from-literal=insertkey=${NEWRELIC_INSERT_KEY} --from-literal=querykey=${NEWRELIC_QUERY_KEY} -n ${SYSTEM_NAMESPACE}
kubectl annotate secret newrelic-account-details kubed.appscode.com/sync="" -n ${SYSTEM_NAMESPACE} --overwrite
# TODO Following secret needs to be defined for all namespaces
kubectl create secret generic newrelic-agent  --from-literal=licensekey=${NEWRELIC_LICENSE_KEY} -n ${SYSTEM_NAMESPACE}
kubectl annotate secret newrelic-agent kubed.appscode.com/sync="" -n ${SYSTEM_NAMESPACE} --overwrite
######################################################################
########## End of secret creations
######################################################################

####################################################################
###################### Application deployments
####################################################################
helm repo add distplat-helm https://hub.ienergycloud.io/artifactory/distplat-helm/ \
  --username ${IENERGY_LOGIN} --password ${IENERGY_PWD}
helm repo update

export CLOUD_VENDOR='aws'
[[ $DO_USE_HTTPS == true ]] && export PROTOCOL="https" || export PROTOCOL="http"
# Platadmin
helm install platadmin distplat-helm/platadmin --version 3.2 \
  --namespace ${SYSTEM_NAMESPACE} \
  --set fullnameOverride=platadmin \
  --set image.tag=2.1.0 \
  --set extraEnv.HOSTED_ZONE=${HOSTED_ZONE} \
  --set extraEnv.PROTOCOL=${PROTOCOL} \
  --set extraEnv.CLUSTER_DNS=${CLUSTER_NAME}.${CLUSTER_DNS} \
  --set extraEnv.CLOUD_VENDOR=${CLOUD_VENDOR} \
  --set global.cluster.hosts=${CLUSTER_NAME}.${CLUSTER_DNS} \
  --set global.cloud.vendor=${CLOUD_VENDOR}


kubectl apply -f ~/script/manifest/examples/helloservice.yaml
kubectl apply -f ~/script/manifest/ow/owsurveyaccessor.yaml
#kubectl apply -f ~/script/manifest/system/postgres/postgres.yaml
kubectl apply -f ~/script/manifest/examples/httpbin.yaml
kubectl apply -f ~/script/manifest/system/istio/app-gateway.yaml
kubectl apply -f ~/script/manifest/system/istio/svc-gateway.yaml

sleep 30

#main dns pointing
python3.6 ~/script/modules/add-domain.py istio-ingressgateway istio-system ${CLUSTER_NAME}.${CLUSTER_DNS} ${HOSTED_ZONE}
python3.6 ~/script/modules/add-domain.py istio-ingressgateway istio-system *.${CLUSTER_NAME}.${CLUSTER_DNS} ${HOSTED_ZONE}
python3.6 ~/script/modules/add-domain.py nginx-ingress-controller ${SYSTEM_NAMESPACE} ${CLUSTER_NAME}-admin.${CLUSTER_DNS} ${HOSTED_ZONE}
python3.6 ~/script/modules/add-domain.py nginx-ingress-controller ${SYSTEM_NAMESPACE} *.${CLUSTER_NAME}-admin.${CLUSTER_DNS} ${HOSTED_ZONE}
[ ! -z "${K8S_ZONE}" ] && python3.6 ~/script/modules/add-domain.py nginx-ingress-controller ${SYSTEM_NAMESPACE} *.${K8S_ZONE_NAME} ${K8S_ZONE}

#monitoring dns pointing
#python3.6 ~/script/modules/add-domain.py nginx-ingress-controller ${SYSTEM_NAMESPACE} grafana.${CLUSTER_NAME}-admin.${CLUSTER_DNS} ${HOSTED_ZONE}
#python3.6 ~/script/modules/add-domain.py nginx-ingress-controller ${SYSTEM_NAMESPACE} alert.${CLUSTER_NAME}-admin.${CLUSTER_DNS} ${HOSTED_ZONE}
#python3.6 ~/script/modules/add-domain.py nginx-ingress-controller ${SYSTEM_NAMESPACE} prom.${CLUSTER_NAME}-admin.${CLUSTER_DNS} ${HOSTED_ZONE}
#python3.6 ~/script/modules/add-domain.py nginx-ingress-controller ${SYSTEM_NAMESPACE} postgres.${CLUSTER_NAME}-admin.${CLUSTER_DNS} ${HOSTED_ZONE}

#kibana dns pointing
#python3.6 ~/script/modules/add-domain.py nginx-ingress-controller ${SYSTEM_NAMESPACE} kibana.${CLUSTER_NAME}-admin.${CLUSTER_DNS} ${HOSTED_ZONE}
#sleep 10

#tracing dns pointing
#python3.6 ~/script/modules/add-domain.py nginx-ingress-controller ${SYSTEM_NAMESPACE} tracing.${CLUSTER_NAME}-admin.${CLUSTER_DNS} ${HOSTED_ZONE}

# Moved it up as many services depend on it

##### Examples

#ubectl apply -f ~/script/manifest/examples/demoApp.yaml
#kubectl apply -f ~/script/manifest/iam-roles-k8s/distplat-dev.role.yaml
#kubectl apply -f ~/script/manifest/iam-roles-k8s/distplat-dev.rolebinding.yaml
# todo:  create ecr secret

#kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v1.10.1/src/deploy/recommended/kubernetes-dashboard.yaml

#sleep 30

# Grafana password provisioning
sudo sed -i "s#{{GRAFANA_PASSWORD}}#${GRAFANA_PASSWORD}#g" ~/script/manifest/system/monitoring/customConfig.yaml

kubectl create namespace monitoring

#install monitoring tools for k8s cluster
# workaround as promethues-operator does not work with helm3 yet (crd)
kubectl apply -f ~/script/manifest/system/monitoring/crd/monitoring.coreos.com_alertmanagers.yaml --validate=false
kubectl apply -f ~/script/manifest/system/monitoring/crd/monitoring.coreos.com_prometheuses.yaml --validate=false
kubectl apply -f ~/script/manifest/system/monitoring/crd/monitoring.coreos.com_prometheusrules.yaml --validate=false
kubectl apply -f ~/script/manifest/system/monitoring/crd/monitoring.coreos.com_servicemonitors.yaml --validate=false
kubectl apply -f ~/script/manifest/system/monitoring/crd/monitoring.coreos.com_podmonitors.yaml --validate=false

helm install prom stable/prometheus-operator \
--namespace monitoring \
--set kubelet.serviceMonitor.https=true \
--set grafana.sidecar.dashboards.enabled=true \
--set grafana.sidecar.dashboards.label=grafana_dashboard \
--set prometheus-node-exporter.nodeSelector.'kubernetes\.io/os'="linux" \
--set grafana.sidecar.datasources.enabled=true \
--set prometheusOperator.createCustomResource=false \
--set grafana.sidecar.datasources.label=grafana_datasource \
-f ~/script/manifest/system/monitoring/customConfig.yaml --version 5.0.11

#sleep 30

kubectl apply -f ~/script/manifest/system/monitoring/cloudwatch-datasource-configmap.yaml
kubectl apply -f ~/script/manifest/system/monitoring/dashboards-confmaps
kubectl apply -f ~/script/manifest/system/monitoring/grafana.yaml
kubectl apply -f ~/script/manifest/system/monitoring/prom.yaml
kubectl apply -f ~/script/manifest/system/monitoring/alert.yaml

# install filebeat for mml stack
helm install filebeat distplat-helm/filebeat --version 0.1.6 \
  --set companyName=${FILEBEAT_COMPANYNAME} \
  --set clusterName=${CLUSTER_NAME} \
  --set output.logstash=${LOGSTASH_HOSTNAME} \
  --namespace=monitoring

# Billingeventmgr

 BEM_VERSION="2.1.0"

 helm install billingeventmgr distplat-helm/billingeventmgr \
           --version ${BEM_VERSION} \
           --namespace ${SYSTEM_NAMESPACE} \
           --set global.cluster.hosts=${CLUSTER_NAME}.${CLUSTER_DNS}


#sleep 10

sleep 30

# install prometheus adapter custom metrics
kubectl apply -f ~/script/manifest/system/monitoring/custom-metrics-api

sleep 30

# install efs
kubectl apply -f ~/script/manifest/system/efs/efs.yaml
#sleep 30

#install standard ebs
kubectl apply -f ~/script/manifest/system/ebs/ebs.yaml
kubectl patch storageclass gp2 -p '{"metadata": {"annotations":{"storageclass.kubernetes.io/is-default-class":"false"}}}'
kubectl delete sc gp2
sleep 10

# install efk
kubectl create namespace logging
#sleep 10
#kubectl apply -f ~/script/manifest/system/efk/elastic-search-master.yaml
#sleep 60
#kubectl apply -f ~/script/manifest/system/efk/elastic-search-ingest.yaml
#sleep 60
#kubectl apply -f ~/script/manifest/system/efk/elastic-search-data.yaml
#sleep 60
#kubectl apply -f ~/script/manifest/system/efk/fluent-bit.yaml
#sleep 20
#kubectl apply -f ~/script/manifest/system/efk/kibana.yaml
#sleep 10

# install tracing
kubectl apply -f ~/script/manifest/system/tracing/tracing-ingress.yaml
#sleep 10


# install Stakater/Reloader in plat-system namespace for rolling update secrets and configmaps in all namespaces.
helm repo add stakater https://stakater.github.io/stakater-charts && helm repo update && helm search repo stakater/reloader
helm install reloader stakater/reloader --version 0.0.26 --namespace ${SYSTEM_NAMESPACE}
sleep 10

# install Weavescope
#python3.6 ~/script/modules/add-domain.py nginx-ingress-controller plat-system weavescope.${CLUSTER_NAME}-admin.${CLUSTER_DNS} ${HOSTED_ZONE}
#helm install phx stable/weave-scope --version 0.11.0 --namespace ${SYSTEM_NAMESPACE}

#metering
#cp ~/script/manifest/system/metering/metering-config.yaml ~/operator-metering/hack/
#export METERING_NAMESPACE=metering
#export METERING_CR_FILE=metering-config.yaml
#pushd ~/operator-metering/hack
#./install.sh
#popd

curl -L -o kube-state-metrics-1.7.2.zip https://github.com/kubernetes/kube-state-metrics/archive/v1.7.2.zip
unzip -q kube-state-metrics-1.7.2.zip 
kubectl apply -f kube-state-metrics-1.7.2/kubernetes -n kube-system

kubectl create -f ~/script/manifest/system/monitoring/newrelic-infrastructure-k8s-latest.yaml
kubectl create -f ~/script/manifest/system/monitoring/newrelic-infrastructure-k8s-events-latest.yaml
sleep 10

#################################################
#END of METERING INSTALLATION
#################################################

# this needed for wait until dns addresses will be available
#sleep 60

# DSIS Security service
bash ~/script/scripts/dsis_install.sh ${CLUSTER_NAME} ${CLUSTER_DNS} ${CLOUD_VENDOR} && echo "continue main install"

echo "Wait for DNS records to get active"
sleep 60
bash ~/script/admin-util/keycloak/setup_keycloak_service_roles.sh "${CLUSTER_NAME}.${CLUSTER_DNS}" ${KEYCLOAK_LOGIN} ${KEYCLOAK_PWD} ${DO_USE_HTTPS}

# Web Framework install
bash ~/script/scripts/wf_install.sh ${CLUSTER_NAME} ${CLUSTER_DNS} ${CLOUD_VENDOR} && echo "continue main install"

# install cluster autoscaler
if [[ ${DO_INSTALL_AUTOSCALER} == "true" ]]; then
  helm install cluster-autoscaler stable/cluster-autoscaler --namespace plat-system --set "autoDiscovery.clusterName=distplat-eks-${CLUSTER_NAME},rbac.serviceAccountName=plat-system,sslCertPath=/etc/kubernetes/pki/ca.crt"
fi
# more precise way of autoscaling, commenting it out since not much tested for v2
# helm install stable/cluster-autoscaler --values=~/script/manifest/system/autoscale/cluster_autoscale_values.yaml
#sleep 10
#kubectl patch storageclass gp2 -p 'allowVolumeExpansion: true'
#sleep 10

# add rancher agent for monitoring
if [[ ${DO_USE_RANCHER_AGENT} == "true" ]]; then
  echo "Adding rancher agent for cluster monitoring"
  kubectl apply -f https://${RANCHER_SERVER}/v3/import/${RANCHER_AGENT_YAML_FILE}
fi
