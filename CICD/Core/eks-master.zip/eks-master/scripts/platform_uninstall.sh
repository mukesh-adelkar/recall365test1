#!/bin/bash

########################################################
### script for clean up resources during cluster destroy
######################################################## 

set -x

export CLUSTER_NAME=${1}

DO_DROP_DATABASE="false"
if [ "$2" = "--drop-database" ]; then
     DO_DROP_DATABASE="true"
fi

echo "Deleting the plat-system namespace..."
#kubectl delete namespaces plat-system
echo "Deleting the Istio ingressgateway..."
kubectl delete svc istio-ingressgateway -n=istio-system
kubectl delete crd --all || true

kubectl delete pvc prometheus-prom-prometheus-operator-prometheus-db-prometheus-prom-prometheus-operator-prometheus-0  -n monitoring || true

echo "Remove nginx-ingress gateway"
helm delete nginx-ingress -n plat-system
sleep 60

echo "Remove istio"
helm delete istio -n istio-system
sleep 60

#echo "Deleting leaking reesources"
#python3.6 /home/centos/script/modules/remove_leaking.py ${CLUSTER_NAME}

# Remove ELBs at the end - ELBs should already have been removed by deletion of Istio
#echo "Removing load-balancers..."
#python3.6 /home/centos/script/modules/remove_elbs.py ${CLUSTER_NAME}

if [[ ${DO_DROP_DATABASE} == "true" ]]; then
    echo "Removing the Postgresql database..."
    #set +x
    /home/centos/script/scripts/aurora/create_db.sh ${PGHOSTNAME} ${PGPASSWORD} ${CLUSTER_NAME} --destroy
    #set -x
fi

