Prerequisites:

1. SSM SSH key
2. EMR S3 bucket
3. Platform S3 bucket
4. certificate for HTTPS
5. Route53 Zone ID