***Platform Release Steps***

1. Update `ReleaseNotes.md`
2. Create the branch with format `release-[#].[#].[#]`, e.g., `release-3.5.0` for the following repositories:

    1. phoenix-base
    2. phoenix-aws
    3. phoenix-common-aws
    4. distplat-infra
    5. doc
    6. df14-template

4. Update the branch reference in `download_base_module.tf` from `master` to the name of the new branch
5. Update any snapshot docker images (distplat/phoenix-base/blob/master/manifest/system/admin-app/platadmin.yaml)
6. Update branch references in `terraform.tfvars` files for every component
7. Update `version.txt` in the branch
8. Go back to the master branch and bump the `version.txt` to the next snapshot version
9. Freeze the new release branch