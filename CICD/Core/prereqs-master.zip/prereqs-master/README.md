# terraform-aws-dsif-s3

Module to deploy S3 folders needed by DSIF

* dsif-${deployment_name}-eks   
* dsif-${deployment_name}-emr   
* dsif-${deployment_name}-jupyter   

Technical debt notes:
* Need to update S3 to enable "block all public access"