To deploy database, run `./setup.sh [OPERATION] [CLUSTER_NAME] "[ENGINEER_NAME]"`.
