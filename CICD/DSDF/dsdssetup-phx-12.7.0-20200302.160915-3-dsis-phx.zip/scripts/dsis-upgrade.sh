#!/bin/sh

########################################################
### script for Upgrading DSIS products
########################################################


usage () {
        echo
        echo "Usage: ${0}  [optional parameters]"
        echo ""
		echo -e "\nExample: $0 --suffix \"coredev\" --chartversion \"12.6.0\""
        echo "Options"
        echo ""
		echo " --suffix - Namespace suffix e.g. coredev/datadev/qa etc"		
        echo " --chartversion - helm chart version to upgrade to e.g. 12.6.0,12.6.1 etc"
        echo " -x|--debug - print debug messages"
        echo " -h|--help - usage"
        echo ""
}

upgrade_chart() {
        #Does not exist
        retval=1
        svc=$1
        cmd=$2
        if [ ! -z "$svc" ];then
                retval=0
				if [ "$isV2Helm" == "true" ];then
					helm get $svc > /dev/null 2>&1
				else
					helm get manifest $svc -n ${namespace} > /dev/null 2>&1			
				fi
                if [ $? == 0 ]; then
						echo "Upgrading '$svc'..."
                        $cmd && sleep 5
                        retval=$?
                else
                        echo "Warning:Release with name '$service' not found. Skipping..."
                fi
        fi

        return $retval
}

chartversion="12.7.0-dev"
namespace="dsis-system"
suffix=""
isV2Helm="false"
isProdnNS="true"


while [ "$1" != "" ]; do
    case $1 in
       --suffix )
            shift
            suffix=$(echo $1 | tr '[:upper:]' '[:lower:]')
			namespace="$namespace-$suffix"
			isProdnNS="false"
            ;;			
       --chartversion | --chartVersion )
            shift
            chartversion=$1
            ;;
       -x | --debug )
            DEBUG="Y"
            ;;
       -h | --help )
            usage
            exit 1
            ;;
       * )
            usage
            exit 1
    esac
    shift
done


proceedWithUpgrade="N"
echo "This will upgrade services in namespace:'$namespace' to chart version:${chartversion}."
read -e -p "Proceed ?(Y/N)? " proceedWithUpgrade

if [ "${proceedWithUpgrade,,}" != "y" ]; then 
	exit 1
fi


if [ $(helm version | grep Server > /dev/null 2>&1 && echo 1 || echo 0) -eq 1 ]; then
	isV2Helm="true"
	echo "Warning: Using deprecated version of helm (V2)..."
fi

helm repo list
helm repo update


platNamespace="plat-system"
if [ "$isProdnNS" == "false" ];then
	platNamespace="${namespace}"
fi

#dssecurity
service="dssecurity${suffix}"
helmNSArg="--namespace ${platNamespace}"
atomicArg="--atomic"
forceArg=""
if  [ "$isV2Helm" == "true" ]; then
	helm get manifest ${service}  > /dev/null 2>&1
	helmNSArg=""
	atomicArg=""
	forceArg="--force"
else
	helm get manifest ${service} --namespace ${platNamespace}  > /dev/null 2>&1
fi

RESULT=$?
if [ $RESULT != 0 ]; then
	echo "Warning:Release with name '$service' not found. Skipping..."
else 
	echo "Upgrading dssecurity..."
	helm upgrade ${service} distplat-helm/dssecurity --version ${chartversion}  ${atomicArg} ${forceArg} ${helmNSArg} 
fi


helmNSArg="--namespace ${namespace}"
if  [ "$isV2Helm" == "true" ]; then
	helmNSArg=""
fi

commonSetting="--version ${chartversion} ${atomicArg} ${forceArg} ${helmNSArg}"

#dsconfig
service="conf${suffix}"
cmd="helm upgrade ${service} distplat-helm/dsconfig ${commonSetting} "
upgrade_chart "${service}" "$cmd"  

#dssearchserver
service="dssearchserver${suffix}"
cmd="helm upgrade ${service} distplat-helm/dssearchserver ${commonSetting} "
upgrade_chart "${service}" "$cmd"  

#dsnotification
service="dsnotification${suffix}"
cmd="helm upgrade ${service} distplat-helm/dsnotification ${commonSetting} "
upgrade_chart "${service}" "$cmd"  

#dsbpm
service="dsbpm${suffix}"
cmd="helm upgrade ${service} distplat-helm/dsbpm ${commonSetting} "
upgrade_chart "${service}" "$cmd"  


#dssearch plugin
service="dssearch${suffix}"
cmd="helm upgrade ${service} distplat-helm/dssearch ${commonSetting} "
upgrade_chart "${service}" "$cmd"  


#dstransfer
service="dstransfer${suffix}"
cmd="helm upgrade ${service} distplat-helm/dstransfer ${commonSetting} "
upgrade_chart "${service}" "$cmd"  

#dsdq
service="dsdq${suffix}"
cmd="helm upgrade ${service} distplat-helm/dsdq ${commonSetting} "
upgrade_chart "${service}" "$cmd"  


#Start connectors
service="dsdata${suffix}"
upgrade_chart "${service}" "helm upgrade ${service} distplat-helm/dsdata ${commonSetting} "

service="dsdsow${suffix}"
cmd="helm upgrade ${service} distplat-helm/dsdsow ${commonSetting} "
upgrade_chart "${service}" "$cmd"      

service="dsdsedm${suffix}"
cmd="helm upgrade ${service} distplat-helm/dsdsedm ${commonSetting} "
upgrade_chart "${service}" "$cmd"      

service="dsdsrecall${suffix}"
cmd="helm upgrade ${service} distplat-helm/dsdsrecall ${commonSetting} "
upgrade_chart "${service}" "$cmd"      

service="dsdsrecallng${suffix}"
cmd="helm upgrade ${service} distplat-helm/dsdsrecallng ${commonSetting} "
upgrade_chart "${service}" "$cmd"      

service="dsdsph${suffix}"
cmd="helm upgrade ${service} distplat-helm/dsdsph ${commonSetting} "
upgrade_chart "${service}" "$cmd"     

echo "DSIS upgrade completed..."


