#!/bin/sh

########################################################
### Script for creating and initializing a namespace
########################################################

function usage {
        echo
        echo "Usage: ./${0} -c cluster -n <namespace> -s <suffix>  [optional parameters]"
        echo ""
		echo -e "\nExample: $0 -c distdsis -n dsis-system-core-dev  -s \"c\" ---domain \"landmarksoftware.io\"  --chartversion 12.6.0"
        echo "Options"
        echo ""
        echo " --chartversion - helm chart version to install 12.5.0/12.5.1/12.6.0 etc"
		echo " --domain - Cluster DNS e.g. landmarksoftware.io"
        echo ""
}

cluster=""
clusterDNS="landmarksoftware.io"
namespace=""
suffix=""
chartversion="12.6.0"
isV2Helm="false"
isProdnNS="false"
debug="N"

if [ "$1" = "" ]; then
  usage
  exit 1
fi

while [ "$1" != "" ]; do
    case $1 in
       -c | --cluster )
            shift
            cluster=$(echo $1 | tr '[:upper:]' '[:lower:]')
            ;;
       -n | --namespace )
            shift
            namespace=$(echo $1 | tr '[:upper:]' '[:lower:]')
			isProdnNS=$([ "$namespace" == "dsis-system" ] && echo "true" || echo "false")
            ;;
       -s | --suffix )
            shift
            suffix=$(echo $1 | tr '[:upper:]' '[:lower:]')
            ;;
       --domain )
            shift
            clusterDNS=$(echo $1 | tr '[:upper:]' '[:lower:]')
            ;;
       --chartversion )
            shift
            chartversion=$1
            ;;
       -x | --debug )
            debug="Y"
            ;;			
       * )
            usage
            exit 1
    esac
    shift
done

if [[  -z "$cluster" || -z "$namespace" || -z "$suffix" ]]; then
	echo "Not all parameters specified. Check usage and try again"
	exit 1
fi

if [ $isProdnNS == "dsis-system" ]; then
	echo "This script cannot be run on a production namespace."
	exit 1
fi

if [ $(helm version | grep Server > /dev/null 2>&1 && echo 1 || echo 0) -eq 1 ]; then
	isV2Helm="true"
fi

if [ "${debug}" == "Y" ]; then
    echo cluster: $cluster
	echo namespace: $namespace
	echo suffix: $suffix	
    echo clusterDNS: $clusterDNS
    echo chartversion: $chartversion
	echo isV2Helm: $isV2Helm
fi


# Create  namespace for dsis services
kubectl get namespace $namespace > /dev/null 2>&1
RESULT=$?
if [ $RESULT != 0 ]; then
	echo "Creating namespace $namespace..."
	kubectl create namespace $namespace && sleep 5
	RESULT=$?
	if [ $RESULT != 0 ]; then
		echo "Namespace creation failed.Please crete manually and try again"
		exit 1		
	fi
	kubectl label namespace $namespace istio-injection=enabled 
else
	echo "Namespace $namespace already exists..."
fi


kubectl get serviceaccount $namespace -n $namespace > /dev/null 2>&1 || cat $(dirname "$0")/dsis-service-account.yaml | sed  "s/<NAMESPACE>/${namespace}/g"  | kubectl apply -f - 
      
kubectl get deployment postgres -n $namespace > /dev/null 2>&1 || cat $(dirname "$0")/postgres-setup.yaml | sed  "s/<NAMESPACE>/${namespace}/g"  |  kubectl apply -f - 

kubectl apply -f $(dirname "$0")/dssecurity-secret.yaml -n ${namespace} 
#kubectl create secret generic newrelic-account-details  --from-literal=accountid=2541618   --from-literal=insertkey=NRII-rCYQb2G1SvGSQaXi-l9x9CIqkH8aHMnP --from-literal=querykey=NRIQ-VPzVQSXi5sEYL2BRqq25fYfkNEKu0jJu -n plat-system
kubectl create secret generic newrelic-agent  --from-literal=licensekey=6c18a41e80f98ec00c8db12515146a18c8c6NRAL -n ${namespace}

kubectl apply -f $(dirname "$0")/postgres-secret.yaml -n ${namespace}

helm repo update

#dsecurity
kubectl get deployment dssecurity${suffix} -n $namespace > /dev/null 2>&1
if [ $? != 0 ]; then
	if [ "$isV2Helm" == "true" ];then
		helm install --name dssecurity${suffix} distplat-helm/dssecurity --version ${chartversion}   --set global.cluster.hosts=${cluster}.${clusterDNS}  --set fullnameOverride=dssecurity${suffix}  --set extraEnv.POSTGRES_HOST=postgres.${namespace} --namespace=${namespace}
	else
		helm install dssecurity${suffix} distplat-helm/dssecurity --version ${chartversion}   --set global.cluster.hosts=${cluster}.${clusterDNS}  --set fullnameOverride=dssecurity${suffix}  --set extraEnv.POSTGRES_HOST=postgres.${namespace} --namespace=${namespace}
	fi
	sleep 5
else
	echo "dssecurity already deployed!" 
fi

echo "Namespace initialized successfully..."
exit 0

