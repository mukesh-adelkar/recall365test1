#!/bin/sh

########################################################
### script for installing DSIS products
########################################################

usage () {
        echo
        echo "Usage: ${0} -c <clustername> [optional parameters]"
        echo ""
		echo -e "\nExample: $0 -c distdsis --suffix \"coredev\"  --all --createDS"
        echo "Options"
        echo ""
        echo " -cl|--cloud  <azure/aws> - Cloud deployment for Azure or AWS(default)"
		echo " --suffix - Namespace suffix e.g. coredev/datadev/qa etc"		
        echo " --All - deploy all DSIS services "
        echo " --secserver - deploy only security services "
        echo " --base - deploy only base services "
        echo " --connectors - deploy only connector DSIS images "
        echo " --disableOW - do not deploy Openworks Connector services"
        echo " --disableEDM - do not deploy EDM Connector services"
        echo " --disableRECALL - do not deploy RECALL Connector services"
        echo " --disableRECALLNG - do not deploy RECALLNG Connector services"
        echo " --disableCDS - do not deploy CDS Connector services"
        echo " --createDS - create DataSources Automatically"
        echo " --chartversion - helm chart version to install 12.5.0/12.5.1/12.6.0 etc"
        echo " --enableProbes - enable Liveness and Readiness Probes for Connectors"
		echo " --domain - Cluster DNS e.g. landmarksoftware.io"		
        echo " -x|--debug - print debug messages"
        echo " -i|--interactive - specify inputs interactively"
        echo " -h|--help - usage"
        echo ""
}

install_chart() {
        #Does not exist
        retval=1
        svc=$1
        cmd=$2
        if [ ! -z "$svc" ];then
                retval=0
				if [ "$isV2Helm" == "true" ];then
					helm get $svc > /dev/null 2>&1
				else
					helm get manifest $svc -n ${namespace} > /dev/null 2>&1			
				fi
                if [ $? != 0 ]; then
						echo "$cmd"
                        $cmd && sleep 5
                        retval=$?
                else
                        echo "Service '$svc' already exists..."
                fi
        fi

        return $retval
}


chartversion="12.6.0-dev"
namespace="dsis-system"
suffix=""
secserver="N"
cloudprovider="AWS"
CLUSTER_DNS="landmarksoftware.io"
base="N"
connectors="N"
enableOW="N"
enableEDM="N"
enableRecall="N"
enableRecallNG="N"
enableCDS="N"
createDS="N"
enableProbe="N"
probes="--set livenessProbe=false,readinessProbe=false"
isV2Helm="false"
isProdnNS="true"

if [ "$1" = "" ]; then
  usage
  exit 1
fi

while [ "$1" != "" ]; do
    case $1 in
       -c | --clusterName )
            shift
            CLUSTER_NAME=$1
            ;;
       --suffix )
            shift
            suffix=$(echo $1 | tr '[:upper:]' '[:lower:]')
			namespace="$namespace-$suffix"
			isProdnNS="false"
            ;;			
       --domain )
            shift
            CLUSTER_DNS=$1
            ;;
       -z | --zone )
            shift
            HOSTED_ZONE=$1
            ;;
       -cl | --cloud | --CLOUD )
            shift
            cloudprovider=$1
            ;;
       --all | --ALL | --All )
            secserver="Y"
            base="Y"
            connectors="Y"
            enableOW="Y"
            enableEDM="Y"
            enableRecall="Y"
            enableRecallNG="Y"
            enableCDS="Y"
            ;;
       --secserver | --SECSERVER )
            secserver="Y"
            ;;
       --base | --BASE )
            base="Y"
            ;;
       --connectors | --CONNECTORS )
            connectors="Y"
            enableOW="Y"
            enableEDM="Y"
            enableRecall="Y"
            enableRecallNG="Y"
            enableCDS="Y"
            ;;
       --disableOW | --disableow )
            enableOW="N"
            ;;
       --disableEDM | --disableedm )
            enableEDM="N"
            ;;
       --disableRECALL | --disablerecall )
            enableRecall="N"
            ;;
       --disableRECALLNG | --disablerecallng )
            enableRecallNG="N"
            ;;
       --disableCDS | --disablecds )
            enableCDS="N"
            ;;
       --chartversion | --chartVersion )
            shift
            chartversion=$1
            ;;
       --enableProbes | --enableprobes )
            enableProbe="Y"
            ;;
       --OWPASSWD| --owpasswd )
            shift
            OWPASSWD="--set datasource.openworks[0].password=$1"
            ;;
       --EDMPASSWD| --edmpasswd )
            shift
            EDMPASSWD="--set datasource.edm[0].password=$1"
            ;;
       --CDSPASSWD| --cdspasswd )
            shift
            CDSPASSWD="--set datasource.cds[0].password=$1"
            ;;
       --RECALLNGPASSWD| --recallngpasswd )
            shift
            RECALLNGPASSWD="--set datasource.recallng[0].password=$1"
            ;;
       --createDS| --createds | --CREATEDS )
            createDS="Y"
            ;;
       -i | --interactive )
            AskUserInput="Y"
            ;;
       -x | --debug )
            DEBUG="Y"
            ;;
       -h | --help )
            usage
            exit 1
            ;;
       * )
            usage
            exit 1
    esac
    shift
done

if [ "${AskUserInput}" == "Y" ]; then
	read -p "Please specify cluster: " CLUSTER_NAME
	read -p "Please specify suffix: " suffix
	if [ ! -z "$suffix" ]; then
		namespace="$namespace-$suffix"
		isProdnNS="false"
	fi
	
	read -e -p "Please specify domain: " -i "$CLUSTER_DNS" CLUSTER_DNS
	read -e  -p "Please specify cloud vendor (AWS/AZURE)?:" -i "AWS" cloudprovider
	read -e  -p "Do you need to install All DSIS Services (Y/N)?: " -i "Y" AllServices
    if [ "${AllServices}" == "Y" ]; then
            secserver="Y"
            base="Y"
            connectors="Y"
    else
	  if [ -z "$suffix" ]; then
		read -e  -p "Do you need to install DSIS Security Service  (Y/N)?: " -i "N" secserver		
	  fi
      read -e  -p "Do you need to install DSIS Base Services  (Y/N)?: " -i "Y" base
      read -e  -p "Do you need to install Connector Services (Y/N)?: " -i "Y" connectors
    fi
    read -e  -p "Specify the version of Helm charts to deploy 12.5.0/12.5.1/12.6.0?: " -i "$chartversion" chartversion
    if [ "${connectors}" == "Y" ]; then
      read -e -p "Do you need to install Openworks Services (Y/N)?: " -i "N" enableOW
      read -e -p "Do you need to install EDM Connector Services (Y/N)?: " -i "N" enableEDM
      read -e -p "Do you need to install Classic Recall Connector Services (Y/N)?: " -i "N" enableRecall
      read -e -p "Do you need to install RecallNG Connector Services (Y/N)?: " -i "N" enableRecallNG
      read -e -p "Do you need to install CDS Connector Services (Y/N)?: " -i "N" enableCDS
      read -e -p "Do you need to enable Probes for Connector Services (Y/N)?: " -i "Y" enableProbe
      read -e -p "Do you need to configure the datasources (Y/N)?. Before you can create the data sources automatically, the datasources.yaml file should be properly setup: " -i "N" createDS
    fi

    if [ "${createDS}" == "Y" ]; then
       if [ "${enableOW}" == "Y" ]; then
    	  read -s -p "Please provide password for OW_SERVER_USER: " OWPWD
          echo
          OWPASSWD="--set datasource.openworks[0].password=$OWPWD"
       fi
       if [ "${enableEDM}" == "Y" ]; then
    	  read -s -p "Please provide password for EDM_SERVER_USER: " EDMPWD
          echo
          EDMPASSWD="--set datasource.edm[0].password=$EDMPWD"
       fi
       if [ "${enableCDS}" == "Y" ]; then
    	  read -s -p "Please provide password for CDS Admin User: " CDSPWD
          echo
          CDSPASSWD="--set datasource.cds[0].password=$CDSPWD"
       fi
       if [ "${enableRecallNG}" == "Y" ]; then
    	  read -s -p "Please provide password for RecallNG Admin User: " NGPWD
          echo
          RECALLNGPASSWD="--set datasource.recallng[0].password=$NGPWD"
       fi
    fi
fi

if [ "${CLUSTER_NAME}" = "" ]; then
  echo "CLUSTER NAME is mandatory"
  usage
  exit 1
fi

if [ "${CLUSTER_DNS}" = "" ]; then
  echo "CLUSTER DNS is mandatory"
  usage
  exit 1
fi

if [[ "${DEBUG}" == "Y" ||  "${AskUserInput}" == "Y" ]]; then
	echo "------------------Selected options-----------------------"
	echo cloud_provider=$cloudprovider
	echo cluster_name=$CLUSTER_NAME
	echo cluster_dns=$CLUSTER_DNS
	echo namespace=$namespace
	echo install_connectors=$connectors
	echo enableOW=$enableOW
	echo enableEDM=$enableEDM
	echo enableRecall=$enableRecall
	echo enableRecallNG=$enableRecallNG
	echo enableCDS=$enableCDS
	echo "-------------------------------------------------------"
fi

if [ "${AskUserInput}" == "Y" ]; then
	proceedWithInstall="N"
	read -e -p "Proceed  with install?(Y/N)? " proceedWithInstall

	if [ "${proceedWithInstall}" != "y" ]; then 
	   exit 1
	fi
fi

if [ "${cloudprovider}" == "AWS" ]||[ "${cloudprovider}" == "aws" ]; then
    cloud="--set global.cloud.vendor=aws"
else
    cloud="--set global.cloud.vendor=azure"
fi
if [ "${createDS}" == "Y" ]; then
    createDS="--set extraEnv.configdatasource=true"
else
    createDS="--set extraEnv.configdatasource=false"
fi
if [ "${enableOW}" == "Y" ]; then
    installOW="--set installopenworks=Y"
fi
if [ "${enableRecall}" == "Y" ]; then
    installRecall="--set installrecall=Y"
fi
if [ "${enableProbe}" == "Y" ]; then
    probes=""
fi


export PROXY_ENABLED="true"
export PROXY_SCHEME="https"

if [ $(helm version | grep Server > /dev/null 2>&1 && echo 1 || echo 0) -eq 1 ]; then
	isV2Helm="true"
	echo "Warning: Using deprecated version of helm (V2)..."
fi

echo "Installing in namespace:'$namespace' using chart version:${chartversion}..."
if [ "$isProdnNS" == "false" ];then
	init_namespace/init-ns.sh -c "$CLUSTER_NAME" -n "$namespace" -s "$suffix" --domain "$CLUSTER_DNS"  --chartversion "$chartversion"
	if [ $? != 0 ]
	then
		echo "Namespace initialization failed.Exiting..."
		exit 1
	fi
fi

export SERVICE_VALIDATION_END_POINT="${PROXY_SCHEME}://dssecurity${suffix}.${CLUSTER_NAME}.${CLUSTER_DNS}"
echo  "Security server validation url:'$SERVICE_VALIDATION_END_POINT'"...

#helm repo add distplat-helm https://hub.ienergycloud.io/artifactory/distplat-helm/ --username ${IENERGY_LOGIN} --password ${IENERGY_PWD}
helm repo list
helm repo update

helmNameArg=""
if  [ "$isV2Helm" == "true" ]; then
	helmNameArg="--name"
fi	   

if [[ "${secserver}" == "Y"  && "$isProdnNS" == "true" ]]; then
    # Create dsis-system namespace for dsis services
	kubectl get namespace dsis-system > /dev/null 2>&1
    RESULT=$?
    if [ $RESULT != 0 ]; then
	   kubectl create namespace dsis-system &&  kubectl label namespace dsis-system istio-injection=enabled && sleep 10
    fi

    #dssecurity
	if  [ "$isV2Helm" == "true" ]; then
		helm get manifest dssecurity  > /dev/null 2>&1
	else
		helm get manifest dssecurity -n plat-system  > /dev/null 2>&1
	fi
	
    RESULT=$?
    if [ $RESULT != 0 ]; then
		helm install $helmNameArg dssecurity distplat-helm/dssecurity --version ${chartversion}  --set global.cluster.hosts=${CLUSTER_NAME}.${CLUSTER_DNS} --set global.extraEnv.PROXY_ENABLED="${PROXY_ENABLED}" ${cloud} --namespace=plat-system && sleep 30
	else 
	   echo "dssecurity already installed..."
    fi
	
fi

#Poll for security server
export END_TIME_OF_WAITING=$(( $(date +%s) + 600 )) # Wait 10 minutes at most
while : ; do
  echo "[`date +%Y-%m-%dT%H:%M:%S%z`]: Waiting for dssecurity to be available..."
  export status=$(curl --silent --connect-timeout 5 --write-out %{http_code} --output /dev/null "${SERVICE_VALIDATION_END_POINT}")
  if [[ "${status}" == "200" ]]; then
	echo "DSIS Security Server installed successfully"
	break
  fi	

  if [[ $(date +%s) -gt $END_TIME_OF_WAITING ]]; then
	echo "ERROR: Gave up waiting for DSIS deployment to enter completed state.  Please inspect DSIS system manually..."
	exit 1
  fi
  sleep 15
done

#DSIS Pre requisites
echo "helm template --values inputs.yaml ${installOW} ${installRecall} ${cloud} DSISPreReqTemplates > DSISPreReq.yaml"
helm template --values inputs.yaml --set ns=$namespace ${installOW} ${installRecall} ${cloud} DSISPreReqTemplates > DSISPreReq.yaml
kubectl apply -f DSISPreReq.yaml

kubectl get configmap edmcustomvdbcm  -n $namespace >/dev/null 2>&1|| kubectl create cm edmcustomvdbcm --from-file=CustomVDBs/dsdsedm -n $namespace
kubectl get configmap dsdatacustomvdbcm  -n $namespace >/dev/null 2>&1 || kubectl create cm dsdatacustomvdbcm --from-file=CustomVDBs/dsdata -n $namespace

if [ "${enableOW}" == "Y" ]; then
    kubectl get configmap owconfmap  -n $namespace >/dev/null 2>&1 || kubectl create cm owconfmap --from-file=openworks/config/ -n $namespace
fi

platNamespace="plat-system"
if [ "$isProdnNS" == "false" ];then
	platNamespace="$namespace"
fi
commonSetting="global.extraEnv.PROXY_ENABLED=\"${PROXY_ENABLED}\",global.extraEnv.PROXY_SCHEME=\"${PROXY_SCHEME}\",global.cluster.hosts=${CLUSTER_NAME}.${CLUSTER_DNS},extraEnv.KC_PRIVATE_HOST=dssecurity${suffix}.${platNamespace},extraEnv.KC_PUBLIC_HOST=dssecurity${suffix}.${CLUSTER_NAME}.${CLUSTER_DNS},extraEnv.POSTGRES_HOST=postgres.${platNamespace}"

if [ "${base}" == "Y" ]; then
      export status=$(curl --silent --connect-timeout 5 --write-out %{http_code} --output /dev/null "${SERVICE_VALIDATION_END_POINT}")
      if [[ "${status}" == "000" || "${status}" == "301" || "${status}" == "200" ]]; then
		#dsconfig
		service="conf${suffix}"
		install_chart "${service}" "helm install $helmNameArg ${service} distplat-helm/dsconfig --version ${chartversion} --set fullnameOverride=${service} --set ${commonSetting} ${cloud} --namespace=$namespace"
		
		#dssearchserver
		service="dssearchserver${suffix}"
		install_chart "${service}" "helm install $helmNameArg ${service} distplat-helm/dssearchserver --version ${chartversion} --set fullnameOverride=${service} --values inputs.yaml --set ${commonSetting} ${installRecall} ${cloud} --namespace=$namespace"
		
		#dsnotification
		service="dsnotification${suffix}"
		install_chart "${service}" "helm install $helmNameArg ${service} distplat-helm/dsnotification --version ${chartversion} --set fullnameOverride=${service}  --values inputs.yaml --set ${commonSetting} ${installOW} ${installRecall} ${probes} ${cloud}  --namespace=$namespace "
		
		#dsbpm
		service="dsbpm${suffix}"
		install_chart "${service}" "helm install $helmNameArg ${service} distplat-helm/dsbpm --version ${chartversion} --set fullnameOverride=${service} --set ${commonSetting} ${cloud}  --namespace=$namespace"

		#dssearch plugin
		service="dssearch${suffix}"
		install_chart "${service}" "helm install $helmNameArg ${service} distplat-helm/dssearch --version ${chartversion} --set fullnameOverride=${service} --set ${commonSetting} ${cloud}  --namespace=$namespace"

		#dstransfer
		service="dstransfer${suffix}"
		install_chart "${service}" "helm install $helmNameArg ${service} distplat-helm/dstransfer --version ${chartversion} --set fullnameOverride=${service} --values inputs.yaml --set ${commonSetting} ${probes} ${cloud} --namespace=$namespace"

		#dsdq
		service="dsdq${suffix}"
		install_chart "${service}" "helm install $helmNameArg ${service} distplat-helm/dsdq --version ${chartversion} --set fullnameOverride=${service} --set ${commonSetting} ${cloud} --namespace=$namespace"
		#break
      else 
        echo "ERROR: Failed to get response from dssecurity server. Please inspect DSIS system manually..."
        exit 1
      fi
fi   

#kubectl create cm owconfmap --from-file=openworks/config/ -n dsis-system

if [ "${connectors}" == "Y" ]; then
  export status=$(curl --silent --connect-timeout 5 --write-out %{http_code} --output /dev/null "${SERVICE_VALIDATION_END_POINT}")
  echo status ${status}
  if [ "${status}" == "000" ]||[ "${status}" == "301" ]||[ "${status}" == "200" ]; then
     service="dsdata${suffix}"
     install_chart "${service}" "helm install $helmNameArg ${service} --set fullnameOverride=${service} distplat-helm/dsdata --version ${chartversion}  --set ${commonSetting}  --namespace=$namespace"

    if [ "${enableOW}" == "Y" ]; then
       #kubectl create cm owconfmap --from-file=openworks/config/ -n $namespace
       service="dsdsow${suffix}"
	   cmd=" helm install $helmNameArg ${service} --set fullnameOverride=${service} distplat-helm/dsdsow --version ${chartversion} --values inputs.yaml --set ${commonSetting} ${createDS} ${probes} ${cloud}  --namespace=$namespace"
       echo "Deploying Helmchart for DSIS dsdsow"
       install_chart "${service}" "$cmd"      
    fi 
	
    if [ "${enableEDM}" == "Y" ]; then
       service="dsdsedm${suffix}"
	   cmd="helm install $helmNameArg ${service} --set fullnameOverride=${service}  distplat-helm/dsdsedm --version ${chartversion} --values inputs.yaml --set ${commonSetting}  ${createDS} ${probes} ${cloud} --namespace=$namespace"
       echo "Deploying Helmchart for DSIS EDM"
       install_chart "${service}" "$cmd"      
    fi
	
    if [ "${enableRecall}" == "Y" ]; then
       service="dsdsrecall${suffix}"
	   cmd="helm install $helmNameArg ${service} --set fullnameOverride=${service} distplat-helm/dsdsrecall --version ${chartversion} --values inputs.yaml --set ${commonSetting} ${createDS} ${probes} ${cloud} --namespace=$namespace "
       echo "Deploying Helmchart for DSIS Recall"
       install_chart "${service}" "$cmd"      

    fi 

    if [ "${enableRecallNG}" == "Y" ]; then
       service="dsdsrecallng${suffix}"
	   cmd="helm install $helmNameArg ${service} --set fullnameOverride=${service} distplat-helm/dsdsrecallng --version ${chartversion} --values inputs.yaml --set ${commonSetting}  ${createDS} ${probes} ${cloud} --namespace=$namespace"
       echo "Deploying Helmchart for DSIS RecallNG"
       install_chart "${service}" "$cmd"      
    fi 
	
    if [ "${enableCDS}" == "Y" ]; then
       service="dsdsph${suffix}"
	   cmd="helm install $helmNameArg ${service} --set fullnameOverride=${service} distplat-helm/dsdsph --version ${chartversion} --values inputs.yaml --set ${commonSetting} ${createDS}  ${probes} ${cloud} --namespace=$namespace"
       echo "Deploying Helmchart for DSIS powerhub"
       install_chart "${service}" "$cmd"     
    fi 
  else 
    echo "ERROR: Failed to get response from dssecurity server. Please inspect DSIS system manually..."
    exit 1
  fi
fi
echo "DSIS deployment completed..."

