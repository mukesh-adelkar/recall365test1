#!/bin/sh
usage() {
        echo
        echo "Usage: ./dsis_uninstall [options]"
        echo ""
		echo -e "\nExample: $0 --suffix \"coredev\"  --all"
        echo "Options"
        echo ""
		echo " --suffix - Namespace suffix e.g. coredev/datadev/qa etc "
        echo " --all - undeploy all DSIS services "
        echo " --base - undeploy only base services "
        echo " --connectors - undeploy only connector services (Default)"
        echo " -h|--help - usage"
        echo ""
}

exit_on_error () {
	echo $1
	exit 1
}


namespace="dsis-system"
suffix=""
cloudprovider="AWS"
base="Y"
connectors="Y"
secserver="N"
isV2Helm="false"
isProdnNS="true"
debug="N"

if [ "$1" = "" ]; then
  usage
  exit 1
fi

while [ "$1" != "" ]; do
    case $1 in
		--suffix )
			shift
			suffix=$(echo $1 | tr '[:upper:]' '[:lower:]')
			namespace="$namespace-$suffix"
			isProdnNS="false"
			;;
       --all | --ALL | --All )
			base="Y"
			connectors="Y"
			secserver="Y"
			;;
       --base | --BASE )
			base="Y"
			connectors="N"
			secserver="N"
			;;
		--connectors | --CONNECTORS )
			base="N"
			connectors="Y"
			secserver="N"
			;;
       -x | --debug )
            debug="Y"
            ;;				
       * )
			usage
			exit 1
    esac
    shift
done

if [ "${debug}" == "Y" ]; then
	echo namespace: $namespace
	echo base: $base
	echo connectors: $connectors
	echo isV2Helm: $isV2Helm
fi

kubectl get namespace $namespace  >/dev/null 2>&1 || exit_on_error "Namespace '$namespace' doesn't exist or is not valid"


if [ $(helm version | grep Server > /dev/null 2>&1 && echo 1 || echo 0) -eq 1 ]; then
	isV2Helm="true"
	echo "Warning: Using deprecated version of helm (V2)..."
fi

proceedWithUninstall="N"
read -p "Warning: You are about to uninstall DSIS services in namespace:'$namespace'. Proceed (Y/N)? " proceedWithUninstall

if [ "${proceedWithUninstall,,}" != "y" ]; then 
   exit 1
fi

#Core
if [ "${base}" == "Y" ]; then
	if  [ "$isV2Helm" == "true" ]; then
		helm get conf${suffix}  > /dev/null 2>&1 && helm del --purge conf${suffix}	
		helm get dssearchserver${suffix}  > /dev/null 2>&1 && helm del --purge dssearchserver${suffix}
		helm get dsnotification${suffix}  > /dev/null 2>&1 && helm del --purge dsnotification${suffix}
		helm get dsbpm${suffix}  > /dev/null 2>&1 && helm del --purge dsbpm${suffix}
		helm get dssearch${suffix}  > /dev/null 2>&1 && helm del --purge dssearch${suffix}
		helm get dstransfer${suffix}  > /dev/null 2>&1 && helm del --purge dstransfer${suffix}
		helm get dsdq${suffix} > /dev/null 2>&1 && helm del --purge dsdq${suffix}	
	else
		helm get manifest conf${suffix} -n ${namespace} > /dev/null 2>&1 && helm del conf${suffix} -n ${namespace}
		helm get manifest dssearchserver${suffix} -n ${namespace}  > /dev/null 2>&1 && helm del  dssearchserver${suffix} -n ${namespace}
		helm get manifest dsnotification${suffix} -n ${namespace} > /dev/null 2>&1 && helm del dsnotification${suffix} -n ${namespace}
		helm get manifest dsbpm${suffix} -n ${namespace} > /dev/null 2>&1 && helm del  dsbpm${suffix} -n ${namespace}
		helm get manifest dssearch${suffix} -n ${namespace} > /dev/null 2>&1 && helm del dssearch${suffix} -n ${namespace}
		helm get manifest dstransfer${suffix} -n ${namespace} > /dev/null 2>&1 && helm del dstransfer${suffix} -n ${namespace}
		helm get manifest dsdq${suffix} -n ${namespace} > /dev/null 2>&1 && helm del  dsdq${suffix} -n ${namespace}
	fi
fi

#Connector
if [ "${connectors}" == "Y" ]; then
	if  [ "$isV2Helm" == "true" ]; then
		helm get manifest dsdata${suffix}  > /dev/null 2>&1 && helm del  dsdata${suffix} --purge
		helm get manifest dsdsow${suffix}  > /dev/null 2>&1 && helm del  dsdsow${suffix} --purge
		helm get manifest dsdsedm${suffix}  > /dev/null 2>&1 && helm del dsdsedm${suffix} --purge
		helm get manifest dsdsph${suffix}  > /dev/null 2>&1 && helm del dsdsph${suffix} --purge
		helm get manifest dsdsrecall${suffix}  > /dev/null 2>&1 && helm del dsdsrecall${suffix} --purge 
		helm get manifest dsdsrecallng${suffix}  > /dev/null 2>&1 && helm del dsdsrecallng${suffix} --purge
	else
		helm get manifest dsdata${suffix} -n ${namespace} > /dev/null 2>&1 && helm del  dsdata${suffix} -n ${namespace}
		helm get manifest dsdsow${suffix} -n ${namespace} > /dev/null 2>&1 && helm del  dsdsow${suffix} -n ${namespace}
		helm get manifest dsdsedm${suffix} -n ${namespace} > /dev/null 2>&1 && helm del dsdsedm${suffix} -n ${namespace}
		helm get manifest dsdsph${suffix} -n ${namespace} > /dev/null 2>&1 && helm del dsdsph${suffix} -n ${namespace}
		helm get manifest dsdsrecall${suffix} -n ${namespace} > /dev/null 2>&1 && helm del dsdsrecall${suffix} -n ${namespace}
		helm get manifest dsdsrecallng${suffix} -n ${namespace} > /dev/null 2>&1 && helm del dsdsrecallng${suffix} -n ${namespace}
	fi
    
	#PVCs
	kubectl get pvc recall-vol-claim -n ${namespace} > /dev/null 2>&1 && kubectl delete pvc recall-vol-claim -n ${namespace}
	kubectl get pvc recalldata-vol-claim -n ${namespace} > /dev/null 2>&1 && kubectl delete pvc recalldata-vol-claim -n ${namespace}    
	kubectl get pvc ow-vol-claim -n ${namespace} > /dev/null 2>&1 && kubectl delete pvc ow-vol-claim -n ${namespace}
	#Dont delete this as it causes new volumes to created on the provisioner
	#kubectl get pvc dsissharedvolclaim -n dsis-system > /dev/null 2>&1 && kubectl patch pvc dsissharedvolclaim -p '{"metadata":{"finalizers":null}}' -n dsis-system	&& kubectl delete pvc dsissharedvolclaim -n dsis-system
	
    #PVs
	kubectl get pv recall-vol-${namespace}  > /dev/null 2>&1 && kubectl patch pv recall-vol-${namespace} -p '{"metadata":{"finalizers":null}}' &&  kubectl delete pv recall-vol-${namespace} 
	kubectl get pv recalldata-vol-${namespace}  > /dev/null 2>&1 && kubectl patch pv recalldata-vol-${namespace} -p '{"metadata":{"finalizers":null}}' && kubectl delete pv recalldata-vol-${namespace} 
	kubectl get pv ow-vol-${namespace} -n dsis-system > /dev/null 2>&1 && kubectl patch pv ow-vol-${namespace} -p '{"metadata":{"finalizers":null}}' && kubectl delete pv ow-vol-${namespace} 

fi

#Security server for non-production namespace
if [[ "$isProdnNS" != "true" && "$secserver" == "Y"  ]]; then
	if  [ "$isV2Helm" == "true" ]; then
		helm get manifest dssecurity${suffix}  > /dev/null 2>&1 && helm del  dssecurity${suffix} --purge
	else
		helm get manifest dssecurity${suffix} -n ${namespace} > /dev/null 2>&1 && helm del  dssecurity${suffix} -n ${namespace}
	fi
fi

sleep 5
echo "Completed uninstalling services..."

